CREATE TABLE `meeting_notes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`meetingId` int NOT NULL,
	`summary` text,
	`highlights` text,
	`actionItems` text,
	`fullTranscriptText` text,
	`processingStatus` enum('pending','processing','completed','failed') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `meeting_notes_id` PRIMARY KEY(`id`),
	CONSTRAINT `meeting_notes_meetingId_unique` UNIQUE(`meetingId`)
);
--> statement-breakpoint
CREATE TABLE `meetings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`meetingUrl` text NOT NULL,
	`platform` enum('zoom','google_meet','teams','other') NOT NULL DEFAULT 'other',
	`botName` varchar(128) NOT NULL,
	`botAvatarUrl` text,
	`botAvatarKey` text,
	`botId` varchar(128),
	`status` enum('pending','joining','recording','processing','completed','failed') NOT NULL DEFAULT 'pending',
	`title` varchar(256),
	`durationSeconds` int,
	`participantCount` int,
	`errorMessage` text,
	`startedAt` timestamp,
	`endedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `meetings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `subscriptions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`plan` enum('free_trial','monthly','cancelled') NOT NULL DEFAULT 'free_trial',
	`status` enum('active','cancelled','expired') NOT NULL DEFAULT 'active',
	`trialEndsAt` timestamp,
	`currentPeriodStart` timestamp DEFAULT (now()),
	`currentPeriodEnd` timestamp,
	`cancelledAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `subscriptions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `transcripts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`meetingId` int NOT NULL,
	`speaker` varchar(128),
	`content` text NOT NULL,
	`startTimeSeconds` int,
	`endTimeSeconds` int,
	`sequenceOrder` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `transcripts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `displayName` varchar(128);--> statement-breakpoint
ALTER TABLE `users` ADD `avatarUrl` text;--> statement-breakpoint
ALTER TABLE `users` ADD `avatarKey` text;