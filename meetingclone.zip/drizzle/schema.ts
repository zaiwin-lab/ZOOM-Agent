import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  boolean,
  bigint,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  displayName: varchar("displayName", { length: 128 }),
  avatarUrl: text("avatarUrl"),
  avatarKey: text("avatarKey"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const subscriptions = mysqlTable("subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  plan: mysqlEnum("plan", ["free_trial", "monthly", "cancelled"]).default("free_trial").notNull(),
  status: mysqlEnum("status", ["active", "cancelled", "expired"]).default("active").notNull(),
  trialEndsAt: timestamp("trialEndsAt"),
  currentPeriodStart: timestamp("currentPeriodStart").defaultNow(),
  currentPeriodEnd: timestamp("currentPeriodEnd"),
  cancelledAt: timestamp("cancelledAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const meetings = mysqlTable("meetings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  meetingUrl: text("meetingUrl").notNull(),
  platform: mysqlEnum("platform", ["zoom", "google_meet", "teams", "other"]).default("other").notNull(),
  botName: varchar("botName", { length: 128 }).notNull(),
  botAvatarUrl: text("botAvatarUrl"),
  botAvatarKey: text("botAvatarKey"),
  botId: varchar("botId", { length: 128 }),
  status: mysqlEnum("status", ["pending", "joining", "recording", "processing", "completed", "failed"]).default("pending").notNull(),
  title: varchar("title", { length: 256 }),
  durationSeconds: int("durationSeconds"),
  participantCount: int("participantCount"),
  errorMessage: text("errorMessage"),
  startedAt: timestamp("startedAt"),
  endedAt: timestamp("endedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const transcripts = mysqlTable("transcripts", {
  id: int("id").autoincrement().primaryKey(),
  meetingId: int("meetingId").notNull(),
  speaker: varchar("speaker", { length: 128 }),
  content: text("content").notNull(),
  startTimeSeconds: int("startTimeSeconds"),
  endTimeSeconds: int("endTimeSeconds"),
  sequenceOrder: int("sequenceOrder").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const meetingNotes = mysqlTable("meeting_notes", {
  id: int("id").autoincrement().primaryKey(),
  meetingId: int("meetingId").notNull().unique(),
  summary: text("summary"),
  highlights: text("highlights"),
  actionItems: text("actionItems"),
  fullTranscriptText: text("fullTranscriptText"),
  processingStatus: mysqlEnum("processingStatus", ["pending", "processing", "completed", "failed"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = typeof subscriptions.$inferInsert;
export type Meeting = typeof meetings.$inferSelect;
export type InsertMeeting = typeof meetings.$inferInsert;
export type Transcript = typeof transcripts.$inferSelect;
export type InsertTranscript = typeof transcripts.$inferInsert;
export type MeetingNote = typeof meetingNotes.$inferSelect;
export type InsertMeetingNote = typeof meetingNotes.$inferInsert;
