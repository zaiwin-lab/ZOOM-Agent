import { and, desc, eq, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertMeeting,
  InsertMeetingNote,
  InsertSubscription,
  InsertTranscript,
  InsertUser,
  Meeting,
  meetingNotes,
  meetings,
  subscriptions,
  transcripts,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ───────────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};

  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    const value = user[field];
    if (value === undefined) continue;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  }

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }

  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }

  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result[0];
}

export async function updateUserProfile(userId: number, data: { displayName?: string; avatarUrl?: string; avatarKey?: string }) {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set(data).where(eq(users.id, userId));
}

export async function getAllUsers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users).orderBy(desc(users.createdAt));
}

// ─── Subscriptions ────────────────────────────────────────────────────────────

export async function getSubscriptionByUserId(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(subscriptions).where(eq(subscriptions.userId, userId)).limit(1);
  return result[0];
}

export async function createSubscription(data: InsertSubscription) {
  const db = await getDb();
  if (!db) return;
  await db.insert(subscriptions).values(data);
}

export async function updateSubscription(userId: number, data: Partial<InsertSubscription>) {
  const db = await getDb();
  if (!db) return;
  await db.update(subscriptions).set(data).where(eq(subscriptions.userId, userId));
}

export async function ensureSubscription(userId: number) {
  const existing = await getSubscriptionByUserId(userId);
  if (existing) return existing;
  const trialEndsAt = new Date();
  trialEndsAt.setDate(trialEndsAt.getDate() + 30);
  await createSubscription({
    userId,
    plan: "free_trial",
    status: "active",
    trialEndsAt,
    currentPeriodStart: new Date(),
    currentPeriodEnd: trialEndsAt,
  });
  return getSubscriptionByUserId(userId);
}

export async function getAllSubscriptions() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(subscriptions).orderBy(desc(subscriptions.createdAt));
}

// ─── Meetings ─────────────────────────────────────────────────────────────────

export async function createMeeting(data: InsertMeeting) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(meetings).values(data);
  return result[0];
}

export async function getMeetingById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(meetings).where(eq(meetings.id, id)).limit(1);
  return result[0];
}

export async function getMeetingsByUserId(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(meetings).where(eq(meetings.userId, userId)).orderBy(desc(meetings.createdAt));
}

export async function updateMeeting(id: number, data: Partial<InsertMeeting>) {
  const db = await getDb();
  if (!db) return;
  await db.update(meetings).set(data).where(eq(meetings.id, id));
}

export async function getMeetingByBotId(botId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(meetings).where(eq(meetings.botId, botId)).limit(1);
  return result[0];
}

export async function getAllMeetings() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(meetings).orderBy(desc(meetings.createdAt));
}

export async function getMeetingsCount() {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select({ count: sql<number>`count(*)` }).from(meetings);
  return result[0]?.count ?? 0;
}

// ─── Transcripts ──────────────────────────────────────────────────────────────

export async function createTranscript(data: InsertTranscript) {
  const db = await getDb();
  if (!db) return;
  await db.insert(transcripts).values(data);
}

export async function getTranscriptsByMeetingId(meetingId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(transcripts)
    .where(eq(transcripts.meetingId, meetingId))
    .orderBy(transcripts.sequenceOrder);
}

export async function bulkCreateTranscripts(data: InsertTranscript[]) {
  const db = await getDb();
  if (!db || data.length === 0) return;
  await db.insert(transcripts).values(data);
}

// ─── Meeting Notes ────────────────────────────────────────────────────────────

export async function getMeetingNotesByMeetingId(meetingId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(meetingNotes).where(eq(meetingNotes.meetingId, meetingId)).limit(1);
  return result[0];
}

export async function upsertMeetingNotes(data: InsertMeetingNote) {
  const db = await getDb();
  if (!db) return;
  await db
    .insert(meetingNotes)
    .values(data)
    .onDuplicateKeyUpdate({
      set: {
        summary: data.summary,
        highlights: data.highlights,
        actionItems: data.actionItems,
        fullTranscriptText: data.fullTranscriptText,
        processingStatus: data.processingStatus,
      },
    });
}
