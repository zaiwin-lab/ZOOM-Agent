import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  createMeeting,
  ensureSubscription,
  getAllMeetings,
  getAllSubscriptions,
  getAllUsers,
  getMeetingById,
  getMeetingNotesByMeetingId,
  getMeetingsByUserId,
  getMeetingsCount,
  getSubscriptionByUserId,
  getTranscriptsByMeetingId,
  updateMeeting,
  updateSubscription,
  updateUserProfile,
  upsertMeetingNotes,
  bulkCreateTranscripts,
} from "./db";
import { invokeLLM } from "./_core/llm";
import { notifyOwner } from "./_core/notification";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { storagePut } from "./storage";

// ─── Admin guard ─────────────────────────────────────────────────────────────
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Admin only" });
  return next({ ctx });
});

// ─── Helpers ──────────────────────────────────────────────────────────────────
function detectPlatform(url: string): "zoom" | "google_meet" | "teams" | "other" {
  if (url.includes("zoom.us") || url.includes("zoom.com")) return "zoom";
  if (url.includes("meet.google.com")) return "google_meet";
  if (url.includes("teams.microsoft.com")) return "teams";
  return "other";
}

function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

// ─── Router ───────────────────────────────────────────────────────────────────
export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Profile ────────────────────────────────────────────────────────────────
  profile: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      const sub = await ensureSubscription(ctx.user.id);
      return { user: ctx.user, subscription: sub };
    }),

    update: protectedProcedure
      .input(z.object({ displayName: z.string().min(1).max(128).optional() }))
      .mutation(async ({ ctx, input }) => {
        await updateUserProfile(ctx.user.id, { displayName: input.displayName });
        return { success: true };
      }),

    uploadAvatar: protectedProcedure
      .input(z.object({ base64: z.string(), mimeType: z.string() }))
      .mutation(async ({ ctx, input }) => {
        const buffer = Buffer.from(input.base64, "base64");
        const ext = input.mimeType.split("/")[1] ?? "jpg";
        const key = `avatars/${ctx.user.id}-${Date.now()}.${ext}`;
        const { url } = await storagePut(key, buffer, input.mimeType);
        await updateUserProfile(ctx.user.id, { avatarUrl: url, avatarKey: key });
        return { avatarUrl: url };
      }),
  }),

  // ─── Subscription ────────────────────────────────────────────────────────────
  subscription: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      return ensureSubscription(ctx.user.id);
    }),

    upgrade: protectedProcedure.mutation(async ({ ctx }) => {
      const sub = await ensureSubscription(ctx.user.id);
      if (!sub) throw new TRPCError({ code: "NOT_FOUND" });
      const periodEnd = new Date();
      periodEnd.setMonth(periodEnd.getMonth() + 1);
      await updateSubscription(ctx.user.id, {
        plan: "monthly",
        status: "active",
        currentPeriodStart: new Date(),
        currentPeriodEnd: periodEnd,
      });
      return { success: true };
    }),

    cancel: protectedProcedure.mutation(async ({ ctx }) => {
      await updateSubscription(ctx.user.id, {
        plan: "cancelled",
        status: "cancelled",
        cancelledAt: new Date(),
      });
      return { success: true };
    }),
  }),

  // ─── Meetings ────────────────────────────────────────────────────────────────
  meetings: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      const rows = await getMeetingsByUserId(ctx.user.id);
      return rows.map((m) => ({
        ...m,
        durationFormatted: m.durationSeconds ? formatDuration(m.durationSeconds) : null,
      }));
    }),

    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        const meeting = await getMeetingById(input.id);
        if (!meeting) throw new TRPCError({ code: "NOT_FOUND" });
        if (meeting.userId !== ctx.user.id && ctx.user.role !== "admin")
          throw new TRPCError({ code: "FORBIDDEN" });
        const notes = await getMeetingNotesByMeetingId(input.id);
        const transcriptRows = await getTranscriptsByMeetingId(input.id);
        return {
          meeting: { ...meeting, durationFormatted: meeting.durationSeconds ? formatDuration(meeting.durationSeconds) : null },
          notes,
          transcripts: transcriptRows,
        };
      }),

    create: protectedProcedure
      .input(
        z.object({
          meetingUrl: z.string().url(),
          botName: z.string().min(1).max(128),
          botAvatarBase64: z.string().optional(),
          botAvatarMime: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const sub = await ensureSubscription(ctx.user.id);
        if (!sub || sub.status !== "active") {
          throw new TRPCError({ code: "FORBIDDEN", message: "Active subscription required." });
        }

        let botAvatarUrl: string | undefined;
        let botAvatarKey: string | undefined;

        if (input.botAvatarBase64 && input.botAvatarMime) {
          const buffer = Buffer.from(input.botAvatarBase64, "base64");
          const ext = input.botAvatarMime.split("/")[1] ?? "jpg";
          const key = `bot-avatars/${ctx.user.id}-${Date.now()}.${ext}`;
          const { url } = await storagePut(key, buffer, input.botAvatarMime);
          botAvatarUrl = url;
          botAvatarKey = key;
        }

        const platform = detectPlatform(input.meetingUrl);
        const result = await createMeeting({
          userId: ctx.user.id,
          meetingUrl: input.meetingUrl,
          platform,
          botName: input.botName,
          botAvatarUrl,
          botAvatarKey,
          status: "pending",
        });

        // Attempt to deploy via MeetingBaaS if API key is available
        const baasKey = process.env.MEETING_BAAS_API_KEY;
        const meetingId = (result as any)?.insertId ?? null;

        if (baasKey && meetingId) {
          try {
            const payload: Record<string, unknown> = {
              meeting_url: input.meetingUrl,
              bot_name: input.botName,
              recording_mode: "speaker_view",
              entry_message: `Hi, I'm ${input.botName} — an AI meeting assistant here to take notes.`,
              reserved: false,
              speech_to_text: { provider: "Default" },
              automatic_leave: { waiting_room_timeout: 600 },
            };
            if (botAvatarUrl) {
              const fullUrl = botAvatarUrl.startsWith("http")
                ? botAvatarUrl
                : `${process.env.VITE_FRONTEND_FORGE_API_URL ?? ""}${botAvatarUrl}`;
              payload.bot_image = fullUrl;
            }
            const res = await fetch("https://api.meetingbaas.com/bots", {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                "x-meeting-baas-api-key": baasKey,
              },
              body: JSON.stringify(payload),
            });
            if (res.ok) {
              const data = await res.json() as { bot_id?: string };
              await updateMeeting(meetingId, { botId: data.bot_id, status: "joining" });
            } else {
              await updateMeeting(meetingId, { status: "joining" });
            }
          } catch {
            await updateMeeting(meetingId, { status: "joining" });
          }
        } else if (meetingId) {
          // Demo mode: simulate a completed meeting after a short delay
          await updateMeeting(meetingId, { status: "joining" });
          // Schedule demo completion
          setTimeout(async () => {
            await simulateDemoMeeting(meetingId, input.botName);
          }, 5000);
        }

        await notifyOwner({
          title: "New Meeting Deployed",
          content: `User ${ctx.user.name ?? ctx.user.email} deployed a bot to ${input.meetingUrl}`,
        });

        return { meetingId };
      }),

    search: protectedProcedure
      .input(z.object({ meetingId: z.number(), query: z.string() }))
      .query(async ({ ctx, input }) => {
        const meeting = await getMeetingById(input.meetingId);
        if (!meeting) throw new TRPCError({ code: "NOT_FOUND" });
        if (meeting.userId !== ctx.user.id && ctx.user.role !== "admin")
          throw new TRPCError({ code: "FORBIDDEN" });
        const allTranscripts = await getTranscriptsByMeetingId(input.meetingId);
        const q = input.query.toLowerCase();
        const matched = allTranscripts.filter((t) =>
          t.content.toLowerCase().includes(q)
        );
        return matched;
      }),

    processNotes: protectedProcedure
      .input(z.object({ meetingId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const meeting = await getMeetingById(input.meetingId);
        if (!meeting) throw new TRPCError({ code: "NOT_FOUND" });
        if (meeting.userId !== ctx.user.id && ctx.user.role !== "admin")
          throw new TRPCError({ code: "FORBIDDEN" });

        const transcriptRows = await getTranscriptsByMeetingId(input.meetingId);
        if (transcriptRows.length === 0) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "No transcript available yet." });
        }

        const fullText = transcriptRows
          .map((t) => `${t.speaker ?? "Speaker"}: ${t.content}`)
          .join("\n");

        await upsertMeetingNotes({
          meetingId: input.meetingId,
          fullTranscriptText: fullText,
          processingStatus: "processing",
        });

        // Run AI processing
        try {
          const aiResponse = await invokeLLM({
            messages: [
              {
                role: "system",
                content: `You are an expert meeting analyst. Given a meeting transcript, produce a JSON response with exactly these fields:
- "summary": A concise 2-4 sentence executive summary of the meeting.
- "highlights": An array of 3-6 key discussion points or decisions (each as a string).
- "actionItems": An array of objects with fields "task" (string), "assignee" (string or null), "dueDate" (string or null).
Return only valid JSON, no markdown.`,
              },
              {
                role: "user",
                content: `Meeting transcript:\n\n${fullText.slice(0, 12000)}`,
              },
            ],
            response_format: {
              type: "json_schema",
              json_schema: {
                name: "meeting_analysis",
                strict: true,
                schema: {
                  type: "object",
                  properties: {
                    summary: { type: "string" },
                    highlights: { type: "array", items: { type: "string" } },
                    actionItems: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          task: { type: "string" },
                          assignee: { type: ["string", "null"] },
                          dueDate: { type: ["string", "null"] },
                        },
                        required: ["task", "assignee", "dueDate"],
                        additionalProperties: false,
                      },
                    },
                  },
                  required: ["summary", "highlights", "actionItems"],
                  additionalProperties: false,
                },
              },
            },
          });

          const rawContent = aiResponse.choices?.[0]?.message?.content;
          const content = typeof rawContent === "string" ? rawContent : "{}";
          const parsed = JSON.parse(content);

          await upsertMeetingNotes({
            meetingId: input.meetingId,
            fullTranscriptText: fullText,
            summary: parsed.summary ?? null,
            highlights: JSON.stringify(parsed.highlights ?? []),
            actionItems: JSON.stringify(parsed.actionItems ?? []),
            processingStatus: "completed",
          });
        } catch (err) {
          await upsertMeetingNotes({
            meetingId: input.meetingId,
            fullTranscriptText: fullText,
            processingStatus: "failed",
          });
          throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "AI processing failed." });
        }

        return { success: true };
      }),
  }),

  // ─── Admin ───────────────────────────────────────────────────────────────────
  admin: router({
    stats: adminProcedure.query(async () => {
      const [allUsers, allMeetings, allSubs] = await Promise.all([
        getAllUsers(),
        getAllMeetings(),
        getAllSubscriptions(),
      ]);
      const totalMeetings = allMeetings.length;
      const completedMeetings = allMeetings.filter((m) => m.status === "completed").length;
      const activeSubscriptions = allSubs.filter((s) => s.status === "active").length;
      return { totalUsers: allUsers.length, totalMeetings, completedMeetings, activeSubscriptions };
    }),

    users: adminProcedure.query(async () => {
      const [allUsers, allSubs, allMeetings] = await Promise.all([
        getAllUsers(),
        getAllSubscriptions(),
        getAllMeetings(),
      ]);
      return allUsers.map((u) => {
        const sub = allSubs.find((s) => s.userId === u.id);
        const meetingCount = allMeetings.filter((m) => m.userId === u.id).length;
        return { ...u, subscription: sub ?? null, meetingCount };
      });
    }),
  }),

  // ─── Webhook (public) ────────────────────────────────────────────────────────
  webhook: router({
    meetingBaas: publicProcedure
      .input(z.object({ event: z.string(), bot_id: z.string().optional() }).passthrough())
      .mutation(async ({ input }) => {
        const botId = input.bot_id;
        if (!botId) return { ok: true };

        const { getMeetingByBotId } = await import("./db");
        const meeting = await getMeetingByBotId(botId);
        if (!meeting) return { ok: true };

        const event = input.event;

        if (event === "bot.status_change") {
          const status = (input as any).status?.code;
          if (status === "in_call_recording") await updateMeeting(meeting.id, { status: "recording", startedAt: new Date() });
          else if (status === "call_ended") await updateMeeting(meeting.id, { status: "processing", endedAt: new Date() });
        }

        if (event === "complete") {
          const data = input as any;
          const duration = data.duration ?? 0;
          const participants = data.participants ?? 0;

          // Process transcript if available
          if (data.transcript && Array.isArray(data.transcript)) {
            const rows = data.transcript.map((seg: any, idx: number) => ({
              meetingId: meeting.id,
              speaker: seg.speaker ?? "Unknown",
              content: seg.words?.map((w: any) => w.text).join(" ") ?? seg.text ?? "",
              startTimeSeconds: Math.floor((seg.start_time ?? 0)),
              endTimeSeconds: Math.floor((seg.end_time ?? 0)),
              sequenceOrder: idx,
            }));
            await bulkCreateTranscripts(rows);
          }

          await updateMeeting(meeting.id, {
            status: "completed",
            durationSeconds: duration,
            participantCount: participants,
            endedAt: new Date(),
          });

          // Trigger AI processing
          const transcriptRows = await getTranscriptsByMeetingId(meeting.id);
          if (transcriptRows.length > 0) {
            const fullText = transcriptRows.map((t) => `${t.speaker ?? "Speaker"}: ${t.content}`).join("\n");
            await upsertMeetingNotes({ meetingId: meeting.id, fullTranscriptText: fullText, processingStatus: "processing" });
            // Fire-and-forget AI processing
            processNotesAsync(meeting.id, fullText).catch(console.error);
          }
        }

        if (event === "failed") {
          await updateMeeting(meeting.id, { status: "failed", errorMessage: (input as any).error ?? "Bot failed" });
        }

        return { ok: true };
      }),
  }),
});

// ─── Async AI processing helper ───────────────────────────────────────────────
async function processNotesAsync(meetingId: number, fullText: string) {
  try {
    const aiResponse = await invokeLLM({
      messages: [
        {
          role: "system",
          content: `You are an expert meeting analyst. Given a meeting transcript, produce a JSON response with exactly these fields:
- "summary": A concise 2-4 sentence executive summary of the meeting.
- "highlights": An array of 3-6 key discussion points or decisions (each as a string).
- "actionItems": An array of objects with fields "task" (string), "assignee" (string or null), "dueDate" (string or null).
Return only valid JSON, no markdown.`,
        },
        { role: "user", content: `Meeting transcript:\n\n${fullText.slice(0, 12000)}` },
      ],
    });
    const rawContent = aiResponse.choices?.[0]?.message?.content;
    const content = typeof rawContent === "string" ? rawContent : "{}";
    const parsed = JSON.parse(content);
    await upsertMeetingNotes({
      meetingId,
      fullTranscriptText: fullText,
      summary: parsed.summary ?? null,
      highlights: JSON.stringify(parsed.highlights ?? []),
      actionItems: JSON.stringify(parsed.actionItems ?? []),
      processingStatus: "completed",
    });
  } catch {
    await upsertMeetingNotes({ meetingId, fullTranscriptText: fullText, processingStatus: "failed" });
  }
}

// ─── Demo simulation helper ───────────────────────────────────────────────────
async function simulateDemoMeeting(meetingId: number, botName: string) {
  await updateMeeting(meetingId, { status: "recording", startedAt: new Date() });
  setTimeout(async () => {
    const demoTranscripts = [
      { speaker: "Alice Chen", content: "Good morning everyone. Let's get started with the Q3 product roadmap review.", startTimeSeconds: 0, endTimeSeconds: 8 },
      { speaker: "Bob Martinez", content: "Thanks Alice. I've prepared the slides. We're on track for the mobile app launch in August.", startTimeSeconds: 9, endTimeSeconds: 18 },
      { speaker: "Alice Chen", content: "Great. What about the API integration timeline? The enterprise clients are asking.", startTimeSeconds: 19, endTimeSeconds: 28 },
      { speaker: "Sarah Kim", content: "The API team expects to complete the core endpoints by end of July. We need two more engineers on that.", startTimeSeconds: 29, endTimeSeconds: 40 },
      { speaker: "Bob Martinez", content: "I'll action that with HR today. Sarah, can you send me the technical specs by Friday?", startTimeSeconds: 41, endTimeSeconds: 50 },
      { speaker: "Sarah Kim", content: "Absolutely. I'll have the full spec document ready by Thursday actually.", startTimeSeconds: 51, endTimeSeconds: 58 },
      { speaker: "Alice Chen", content: "Perfect. Let's also schedule a client demo for the first week of August. Bob, please coordinate with the sales team.", startTimeSeconds: 59, endTimeSeconds: 70 },
      { speaker: "Bob Martinez", content: "Will do. I'll set that up by end of this week.", startTimeSeconds: 71, endTimeSeconds: 77 },
      { speaker: "Alice Chen", content: "Excellent. Any blockers we should be aware of before we wrap up?", startTimeSeconds: 78, endTimeSeconds: 85 },
      { speaker: "Sarah Kim", content: "Just the infrastructure costs — we need budget approval for the additional cloud resources.", startTimeSeconds: 86, endTimeSeconds: 96 },
      { speaker: "Alice Chen", content: "I'll escalate that to finance today. Great meeting everyone, let's reconvene next Tuesday.", startTimeSeconds: 97, endTimeSeconds: 107 },
    ];
    await bulkCreateTranscripts(demoTranscripts.map((t, i) => ({ ...t, meetingId, sequenceOrder: i })));
    await updateMeeting(meetingId, { status: "completed", durationSeconds: 107, participantCount: 3, endedAt: new Date() });
    const fullText = demoTranscripts.map((t) => `${t.speaker}: ${t.content}`).join("\n");
    await upsertMeetingNotes({ meetingId, fullTranscriptText: fullText, processingStatus: "processing" });
    await processNotesAsync(meetingId, fullText);
  }, 8000);
}

export type AppRouter = typeof appRouter;
