import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function createUserCtx(overrides: Partial<TrpcContext["user"]> = {}): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user-1",
      email: "test@example.com",
      name: "Test User",
      displayName: "Test User",
      avatarUrl: null,
      avatarKey: null,
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
      ...overrides,
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as unknown as TrpcContext["res"],
  };
}

function createAdminCtx(): TrpcContext {
  return createUserCtx({ role: "admin", openId: "admin-user" });
}

// ─── Auth ─────────────────────────────────────────────────────────────────────

describe("auth.logout", () => {
  it("clears the session cookie and returns success", async () => {
    const cleared: string[] = [];
    const ctx: TrpcContext = {
      ...createUserCtx(),
      res: { clearCookie: (name: string) => cleared.push(name) } as unknown as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result.success).toBe(true);
    expect(cleared.length).toBe(1);
  });
});

// ─── Platform detection helper ────────────────────────────────────────────────

describe("platform detection", () => {
  const detectPlatform = (url: string): string => {
    if (url.includes("zoom.us") || url.includes("zoom.com")) return "zoom";
    if (url.includes("meet.google.com")) return "google_meet";
    if (url.includes("teams.microsoft.com")) return "teams";
    return "other";
  };

  it("detects zoom URLs", () => {
    expect(detectPlatform("https://zoom.us/j/12345")).toBe("zoom");
    expect(detectPlatform("https://us02web.zoom.us/j/12345")).toBe("zoom");
  });

  it("detects google meet URLs", () => {
    expect(detectPlatform("https://meet.google.com/abc-defg-hij")).toBe("google_meet");
  });

  it("detects teams URLs", () => {
    expect(detectPlatform("https://teams.microsoft.com/l/meetup-join/...")).toBe("teams");
  });

  it("returns other for unknown URLs", () => {
    expect(detectPlatform("https://example.com/meeting")).toBe("other");
  });
});

// ─── Duration formatting helper ───────────────────────────────────────────────

describe("duration formatting", () => {
  const formatDuration = (seconds: number): string => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    if (h > 0) return `${h}h ${m}m`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
  };

  it("formats seconds only", () => {
    expect(formatDuration(45)).toBe("45s");
  });

  it("formats minutes and seconds", () => {
    expect(formatDuration(125)).toBe("2m 5s");
  });

  it("formats hours and minutes", () => {
    expect(formatDuration(3665)).toBe("1h 1m");
  });

  it("formats zero", () => {
    expect(formatDuration(0)).toBe("0s");
  });
});

// ─── JSON parse safety ────────────────────────────────────────────────────────

describe("JSON parse safety for meeting notes", () => {
  const safeParseArray = (str: string | null | undefined): unknown[] => {
    try { return JSON.parse(str ?? "[]"); } catch { return []; }
  };

  it("parses valid JSON array", () => {
    expect(safeParseArray('["item1","item2"]')).toEqual(["item1", "item2"]);
  });

  it("returns empty array for null", () => {
    expect(safeParseArray(null)).toEqual([]);
  });

  it("returns empty array for invalid JSON", () => {
    expect(safeParseArray("not-json")).toEqual([]);
  });

  it("returns empty array for undefined", () => {
    expect(safeParseArray(undefined)).toEqual([]);
  });
});
