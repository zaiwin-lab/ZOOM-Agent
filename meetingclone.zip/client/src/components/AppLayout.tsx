import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import {
  Bot, LayoutDashboard, Plus, User, CreditCard,
  LogOut, Settings, Shield, ChevronRight, Menu, X
} from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { LanguageToggle } from "@/components/LanguageToggle";
import { useLanguage } from "@/contexts/LanguageContext";

const LOGO_URL = "/manus-storage/kobis-logo_df6a415e.jpeg";

// Nav items defined inside component to use translations

interface AppLayoutProps {
  children: React.ReactNode;
  title?: string;
}

export default function AppLayout({ children, title }: AppLayoutProps) {
  const { user, isAuthenticated, loading, logout } = useAuth();
  const [location, navigate] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const { t } = useLanguage();

  const NAV_ITEMS = [
    { href: "/dashboard", icon: LayoutDashboard, label: t("dash.title") },
    { href: "/meetings/new", icon: Plus, label: t("meeting.title") },
    { href: "/profile", icon: User, label: "Profile" },
    { href: "/subscription", icon: CreditCard, label: "Subscription" },
  ];

  const { data: profile } = trpc.profile.get.useQuery(undefined, { enabled: isAuthenticated });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center animate-pulse">
            <Bot className="w-5 h-5 text-primary" />
          </div>
          <p className="text-sm text-muted-foreground">Loading…</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    window.location.href = getLoginUrl();
    return null;
  }

  const displayName = profile?.user?.displayName ?? user?.name ?? "User";
  const avatarUrl = profile?.user?.avatarUrl;
  const initials = displayName.split(" ").map((n: string) => n[0]).join("").toUpperCase().slice(0, 2);

  const Sidebar = ({ mobile = false }: { mobile?: boolean }) => (
    <aside className={cn(
      "flex flex-col h-full",
      mobile ? "w-full" : "w-60 border-r border-border/60 bg-sidebar"
    )}>
      {/* Logo */}
      <div className="flex flex-col items-center px-5 py-4 border-b border-sidebar-border/60">
        <img
          src={LOGO_URL}
          alt="KOBIS Berhad"
          className="h-10 w-auto object-contain mb-2"
          onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
        />
        <div className="text-center">
          <p className="text-[oklch(0.72_0.13_72)] text-[11px] font-bold tracking-widest uppercase leading-none">MeetingClone</p>
          <p className="text-sidebar-foreground/50 text-[9px] tracking-wider leading-none mt-0.5">AI Meeting Intelligence</p>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {NAV_ITEMS.map((item) => {
          const active = location === item.href;
          return (
            <button
              key={item.href}
              onClick={() => { navigate(item.href); setMobileOpen(false); }}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150",
                active
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              )}
            >
              <item.icon className="w-4 h-4 flex-shrink-0" />
              {item.label}
              {active && <ChevronRight className="ml-auto w-3.5 h-3.5 opacity-60" />}
            </button>
          );
        })}

        {user?.role === "admin" && (
          <button
            onClick={() => { navigate("/admin"); setMobileOpen(false); }}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150",
              location === "/admin"
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            )}
          >
            <Shield className="w-4 h-4 flex-shrink-0" />
            Admin
            <Badge variant="secondary" className="ml-auto text-[10px] px-1.5 py-0">Owner</Badge>
          </button>
        )}
      </nav>

      {/* User section */}
      <div className="px-3 py-4 border-t border-border/40">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-sidebar-accent transition-colors">
              <Avatar className="w-7 h-7">
                <AvatarImage src={avatarUrl ?? undefined} />
                <AvatarFallback className="text-xs bg-primary/10 text-primary font-600">{initials}</AvatarFallback>
              </Avatar>
              <div className="flex-1 text-left min-w-0">
                <p className="text-sm font-medium truncate">{displayName}</p>
                <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
              </div>
              <Settings className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-52">
            <DropdownMenuItem onClick={() => navigate("/profile")}>
              <User className="w-4 h-4 mr-2" /> Profile
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate("/subscription")}>
              <CreditCard className="w-4 h-4 mr-2" /> Subscription
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => logout()} className="text-destructive focus:text-destructive">
              <LogOut className="w-4 h-4 mr-2" /> Sign out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </aside>
  );

  return (
    <div className="min-h-screen flex bg-background">
      {/* Desktop sidebar */}
      <div className="hidden md:flex flex-col fixed inset-y-0 left-0 w-60 z-30">
        <Sidebar />
      </div>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-72 bg-sidebar shadow-2xl">
            <div className="flex justify-end p-4">
              <button onClick={() => setMobileOpen(false)} className="p-1.5 rounded-lg hover:bg-sidebar-accent">
                <X className="w-4 h-4" />
              </button>
            </div>
            <Sidebar mobile />
          </div>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col md:ml-60">
        {/* Top bar */}
        <header className="sticky top-0 z-20 flex items-center justify-between px-6 h-14 border-b border-border/60 bg-background/80 backdrop-blur-xl">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setMobileOpen(true)}
              className="md:hidden p-1.5 rounded-lg hover:bg-accent"
            >
              <Menu className="w-4 h-4" />
            </button>
            {title && <h1 className="font-display font-600 text-base">{title}</h1>}
          </div>
          <div className="flex items-center gap-2">
            <LanguageToggle variant="navbar" />
            <Button size="sm" onClick={() => navigate("/meetings/new")} className="bg-[oklch(0.48_0.16_240)] hover:bg-[oklch(0.40_0.16_240)] text-white">
              <Plus className="w-3.5 h-3.5 mr-1.5" /> {t("dash.new")}
            </Button>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
