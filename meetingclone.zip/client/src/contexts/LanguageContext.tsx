import { createContext, useContext, useState, ReactNode } from "react";

export type Language = "en" | "ms" | "zh" | "iban";

export interface LanguageConfig {
  code: Language;
  label: string;
  shortLabel: string;
  flag: string;
}

export const LANGUAGES: LanguageConfig[] = [
  { code: "en",   label: "English",         shortLabel: "EN",   flag: "🇬🇧" },
  { code: "ms",   label: "Bahasa Malaysia",  shortLabel: "BM",   flag: "🇲🇾" },
  { code: "zh",   label: "中文",             shortLabel: "中文", flag: "🇨🇳" },
  { code: "iban", label: "Bahasa Iban",      shortLabel: "IBAN", flag: "🏝️" },
];

// ─── Translation dictionary ──────────────────────────────────────────────────
export const translations: Record<Language, Record<string, string>> = {
  en: {
    // Nav
    "nav.features":      "Features",
    "nav.pricing":       "Pricing",
    "nav.howItWorks":    "How it works",
    "nav.dashboard":     "Go to Dashboard",
    "nav.login":         "Sign in",

    // Hero
    "hero.badge":        "AI Meeting Assistant — Beta",
    "hero.tagline1":     "Clone yourself.",
    "hero.tagline2":     "Never miss a meeting.",
    "hero.tagline.ai":   "Powered by KOBIS AI Intelligence",
    "hero.sub":          "Deploy an AI bot to your Zoom and Google Meet calls. It attends, transcribes, and delivers intelligent summaries — so you can focus on what actually matters.",
    "hero.cta.start":    "Start free — first month on us →",
    "hero.cta.watch":    "See how it works",
    "hero.trust":        "No credit card required · First 30 days free · Cancel anytime",

    // Features
    "features.title":    "Everything you need. Nothing you don't.",
    "features.sub":      "A focused set of powerful features designed to reclaim your time and keep you informed.",
    "features.join":     "AI Clone Joins For You",
    "features.join.d":   "Your personalised bot enters Zoom or Google Meet with your name and photo — no manual attendance needed.",
    "features.transcript":"Real-Time Transcription",
    "features.transcript.d":"Every word captured with speaker identification, timestamps, and high accuracy across accents and languages.",
    "features.summary":  "AI-Powered Summaries",
    "features.summary.d":"Instantly get executive summaries, key highlights, and extracted action items — ready the moment the meeting ends.",
    "features.search":   "Searchable Notes",
    "features.search.d": "Full-text search across all your meeting transcripts and notes. Find any decision or discussion in seconds.",
    "features.export":   "Export Anywhere",
    "features.export.d": "Download your notes as polished PDFs or plain text. Share with your team or archive for compliance.",
    "features.analytics":"Meeting Analytics",
    "features.analytics.d":"Track duration, participant counts, and meeting frequency. Understand where your time really goes.",

    // How it works
    "how.title":         "Up and running in 60 seconds",
    "how.sub":           "Three simple steps to deploy your AI meeting clone.",
    "how.step1.title":   "Paste your meeting link",
    "how.step1.d":       "Copy the Zoom or Google Meet URL and paste it into MeetingClone. Takes 5 seconds.",
    "how.step2.title":   "Confirm your bot's identity",
    "how.step2.d":       "Set the bot's display name and upload an avatar so participants know who it represents.",
    "how.step3.title":   "Receive your notes",
    "how.step3.d":       "The bot joins, records, and delivers a full transcript with AI summary and action items.",

    // Pricing
    "pricing.title":     "Simple, honest pricing",
    "pricing.sub":       "One plan. Everything included. First month completely free.",
    "pricing.plan":      "Pro Monthly",
    "pricing.free":      "🎉 First month FREE",
    "pricing.then":      "Then $29/month. Cancel anytime.",
    "pricing.cta":       "Get started free →",
    "pricing.note":      "No credit card required for free trial",

    // CTA section
    "cta.title":         "Your time is worth more.",
    "cta.sub":           "Join professionals who've reclaimed their schedule with MeetingClone.",
    "cta.btn":           "Start your free month →",

    // Footer
    "footer.tagline":    "AI-powered meeting intelligence for modern professionals.",
    "footer.rights":     "© 2026 MeetingClone by KOBIS Berhad. All rights reserved.",

    // Dashboard
    "dash.title":        "Dashboard",
    "dash.new":          "New Meeting",
    "dash.empty":        "No meetings yet",
    "dash.empty.sub":    "Deploy your first AI clone to a meeting to get started.",

    // New meeting
    "meeting.title":     "New Meeting",
    "meeting.link.label":"Meeting Link",
    "meeting.link.ph":   "Paste Zoom or Google Meet URL…",
    "meeting.bot.name":  "Bot Display Name",
    "meeting.bot.avatar":"Bot Avatar",
    "meeting.submit":    "Deploy AI Clone",

    // General
    "general.loading":   "Loading…",
    "general.error":     "Something went wrong",
    "general.save":      "Save changes",
    "general.cancel":    "Cancel",
    "general.back":      "Back",
  },

  ms: {
    // Nav
    "nav.features":      "Ciri-ciri",
    "nav.pricing":       "Harga",
    "nav.howItWorks":    "Cara ia berfungsi",
    "nav.dashboard":     "Ke Papan Pemuka",
    "nav.login":         "Log masuk",

    // Hero
    "hero.badge":        "Pembantu Mesyuarat AI — Beta",
    "hero.tagline1":     "Klonkan diri anda.",
    "hero.tagline2":     "Jangan lepaskan mesyuarat.",
    "hero.tagline.ai":   "Dikuasakan oleh Kecerdasan AI KOBIS",
    "hero.sub":          "Hantar bot AI ke panggilan Zoom dan Google Meet anda. Ia hadir, merekod, dan menghasilkan ringkasan pintar — supaya anda boleh fokus pada perkara yang benar-benar penting.",
    "hero.cta.start":    "Mulakan percuma — bulan pertama percuma →",
    "hero.cta.watch":    "Lihat cara ia berfungsi",
    "hero.trust":        "Tiada kad kredit diperlukan · 30 hari pertama percuma · Batal bila-bila masa",

    // Features
    "features.title":    "Semua yang anda perlukan. Tiada yang tidak perlu.",
    "features.sub":      "Satu set ciri berkuasa yang direka untuk menjimatkan masa anda dan memastikan anda sentiasa dimaklumkan.",
    "features.join":     "Klon AI Hadir Untuk Anda",
    "features.join.d":   "Bot peribadi anda memasuki Zoom atau Google Meet dengan nama dan foto anda — tiada kehadiran manual diperlukan.",
    "features.transcript":"Transkripsi Masa Nyata",
    "features.transcript.d":"Setiap perkataan dirakam dengan pengenalan penutur, cap masa, dan ketepatan tinggi merentasi pelbagai loghat dan bahasa.",
    "features.summary":  "Ringkasan Berkuasa AI",
    "features.summary.d":"Dapatkan ringkasan eksekutif, perkara utama, dan item tindakan yang diekstrak — sedia sejurus mesyuarat tamat.",
    "features.search":   "Nota Boleh Dicari",
    "features.search.d": "Carian teks penuh merentasi semua transkripsi dan nota mesyuarat anda. Cari sebarang keputusan dalam beberapa saat.",
    "features.export":   "Eksport ke Mana-mana",
    "features.export.d": "Muat turun nota anda sebagai PDF atau teks biasa. Kongsi dengan pasukan atau arkibkan untuk pematuhan.",
    "features.analytics":"Analitik Mesyuarat",
    "features.analytics.d":"Jejak tempoh, bilangan peserta, dan kekerapan mesyuarat. Fahami ke mana masa anda benar-benar pergi.",

    // How it works
    "how.title":         "Berjalan dalam 60 saat",
    "how.sub":           "Tiga langkah mudah untuk menggunakan klon mesyuarat AI anda.",
    "how.step1.title":   "Tampal pautan mesyuarat",
    "how.step1.d":       "Salin URL Zoom atau Google Meet dan tampalkan ke dalam MeetingClone. Mengambil masa 5 saat.",
    "how.step2.title":   "Sahkan identiti bot anda",
    "how.step2.d":       "Tetapkan nama paparan bot dan muat naik avatar supaya peserta tahu siapa yang diwakilinya.",
    "how.step3.title":   "Terima nota anda",
    "how.step3.d":       "Bot hadir, merekod, dan menghantar transkripsi penuh dengan ringkasan AI dan item tindakan.",

    // Pricing
    "pricing.title":     "Harga mudah dan jujur",
    "pricing.sub":       "Satu pelan. Semua termasuk. Bulan pertama percuma sepenuhnya.",
    "pricing.plan":      "Pro Bulanan",
    "pricing.free":      "🎉 Bulan pertama PERCUMA",
    "pricing.then":      "Kemudian $29/bulan. Batal bila-bila masa.",
    "pricing.cta":       "Mulakan percuma →",
    "pricing.note":      "Tiada kad kredit diperlukan untuk percubaan percuma",

    // CTA section
    "cta.title":         "Masa anda lebih berharga.",
    "cta.sub":           "Sertai profesional yang telah menuntut semula jadual mereka dengan MeetingClone.",
    "cta.btn":           "Mulakan bulan percuma anda →",

    // Footer
    "footer.tagline":    "Kecerdasan mesyuarat berkuasa AI untuk profesional moden.",
    "footer.rights":     "© 2026 MeetingClone oleh KOBIS Berhad. Hak cipta terpelihara.",

    // Dashboard
    "dash.title":        "Papan Pemuka",
    "dash.new":          "Mesyuarat Baharu",
    "dash.empty":        "Tiada mesyuarat lagi",
    "dash.empty.sub":    "Gunakan klon AI pertama anda ke mesyuarat untuk bermula.",

    // New meeting
    "meeting.title":     "Mesyuarat Baharu",
    "meeting.link.label":"Pautan Mesyuarat",
    "meeting.link.ph":   "Tampal URL Zoom atau Google Meet…",
    "meeting.bot.name":  "Nama Paparan Bot",
    "meeting.bot.avatar":"Avatar Bot",
    "meeting.submit":    "Gunakan Klon AI",

    // General
    "general.loading":   "Memuatkan…",
    "general.error":     "Sesuatu telah berlaku",
    "general.save":      "Simpan perubahan",
    "general.cancel":    "Batal",
    "general.back":      "Kembali",
  },

  zh: {
    // Nav
    "nav.features":      "功能特点",
    "nav.pricing":       "价格方案",
    "nav.howItWorks":    "使用方法",
    "nav.dashboard":     "进入控制台",
    "nav.login":         "登录",

    // Hero
    "hero.badge":        "AI 会议助手 — 测试版",
    "hero.tagline1":     "克隆您自己。",
    "hero.tagline2":     "永不错过会议。",
    "hero.tagline.ai":   "由 KOBIS AI 智能驱动",
    "hero.sub":          "将 AI 机器人部署到您的 Zoom 和 Google Meet 通话中。它出席、转录并提供智能摘要 — 让您专注于真正重要的事情。",
    "hero.cta.start":    "免费开始 — 第一个月免费 →",
    "hero.cta.watch":    "查看使用方法",
    "hero.trust":        "无需信用卡 · 前30天免费 · 随时取消",

    // Features
    "features.title":    "一切所需，恰到好处。",
    "features.sub":      "一套专注的强大功能，旨在为您节省时间并让您随时了解情况。",
    "features.join":     "AI 克隆代您出席",
    "features.join.d":   "您的个人机器人以您的姓名和照片进入 Zoom 或 Google Meet — 无需手动出席。",
    "features.transcript":"实时转录",
    "features.transcript.d":"每个词语都被捕获，包括说话人识别、时间戳，以及跨口音和语言的高准确度。",
    "features.summary":  "AI 智能摘要",
    "features.summary.d":"即时获取执行摘要、关键亮点和提取的行动项目 — 会议结束后立即就绪。",
    "features.search":   "可搜索笔记",
    "features.search.d": "在所有会议转录和笔记中进行全文搜索。几秒内找到任何决定或讨论。",
    "features.export":   "随处导出",
    "features.export.d": "将笔记下载为精美的 PDF 或纯文本。与团队分享或存档以供合规使用。",
    "features.analytics":"会议分析",
    "features.analytics.d":"跟踪时长、参与人数和会议频率。了解您的时间真正花在哪里。",

    // How it works
    "how.title":         "60秒内即可运行",
    "how.sub":           "三个简单步骤部署您的 AI 会议克隆。",
    "how.step1.title":   "粘贴会议链接",
    "how.step1.d":       "复制 Zoom 或 Google Meet URL 并粘贴到 MeetingClone 中。只需5秒。",
    "how.step2.title":   "确认机器人身份",
    "how.step2.d":       "设置机器人的显示名称并上传头像，让参与者知道它代表谁。",
    "how.step3.title":   "接收您的笔记",
    "how.step3.d":       "机器人加入、录制，并提供带有 AI 摘要和行动项目的完整转录。",

    // Pricing
    "pricing.title":     "简单透明的定价",
    "pricing.sub":       "一个方案。包含一切。第一个月完全免费。",
    "pricing.plan":      "专业月付",
    "pricing.free":      "🎉 第一个月免费",
    "pricing.then":      "之后每月 $29。随时取消。",
    "pricing.cta":       "免费开始 →",
    "pricing.note":      "免费试用无需信用卡",

    // CTA section
    "cta.title":         "您的时间更有价值。",
    "cta.sub":           "加入已用 MeetingClone 重新掌控日程的专业人士。",
    "cta.btn":           "开始您的免费月 →",

    // Footer
    "footer.tagline":    "为现代专业人士提供 AI 驱动的会议智能。",
    "footer.rights":     "© 2026 MeetingClone 由 KOBIS Berhad 提供。版权所有。",

    // Dashboard
    "dash.title":        "控制台",
    "dash.new":          "新建会议",
    "dash.empty":        "暂无会议",
    "dash.empty.sub":    "将您的第一个 AI 克隆部署到会议中以开始使用。",

    // New meeting
    "meeting.title":     "新建会议",
    "meeting.link.label":"会议链接",
    "meeting.link.ph":   "粘贴 Zoom 或 Google Meet URL…",
    "meeting.bot.name":  "机器人显示名称",
    "meeting.bot.avatar":"机器人头像",
    "meeting.submit":    "部署 AI 克隆",

    // General
    "general.loading":   "加载中…",
    "general.error":     "出现错误",
    "general.save":      "保存更改",
    "general.cancel":    "取消",
    "general.back":      "返回",
  },

  iban: {
    // Nav
    "nav.features":      "Pekara",
    "nav.pricing":       "Rega",
    "nav.howItWorks":    "Kemaya ia bejalai",
    "nav.dashboard":     "Ke Papan Pemuka",
    "nav.login":         "Log masuk",

    // Hero
    "hero.badge":        "Pembantu Rapat AI — Beta",
    "hero.tagline1":     "Klon diri nuan.",
    "hero.tagline2":     "Enda ulih tinggal rapat.",
    "hero.tagline.ai":   "Dikuasa AI KOBIS Intelligence",
    "hero.sub":          "Hantar bot AI ke rapat Zoom enggau Google Meet nuan. Ia datai, rakam, enggau ngaga ringkasan pandai — ngambika nuan ulih fokus ba pekara ti betul-betul penting.",
    "hero.cta.start":    "Mula percuma — bulan pertama percuma →",
    "hero.cta.watch":    "Meda kemaya ia bejalai",
    "hero.trust":        "Enda perlu kad kredit · 30 hari pertama percuma · Batal bila-bila",

    // Features
    "features.title":    "Semua ti diperluka. Enda lebih.",
    "features.sub":      "Sekumpulan pekara berkuasa ti direka ngambika nuan jimat masa enggau sentiasa dimaklumka.",
    "features.join":     "Klon AI Datai Ganti Nuan",
    "features.join.d":   "Bot peribadi nuan masuk Zoom atau Google Meet enggau nama enggau gambar nuan — enda perlu datai sendiri.",
    "features.transcript":"Transkripsi Masa Nyata",
    "features.transcript.d":"Tiap-tiap perkataan dirakam enggau pengenalan penutur, cap masa, enggau ketepatan tinggi.",
    "features.summary":  "Ringkasan Berkuasa AI",
    "features.summary.d":"Dapati ringkasan, pekara utama, enggau item tindakan — sedia lebuh rapat udah abis.",
    "features.search":   "Nota Ulih Dicari",
    "features.search.d": "Cari teks penuh dalam semua transkripsi enggau nota rapat nuan. Dapati keputusan dalam beberapa saat.",
    "features.export":   "Eksport Kemana-mana",
    "features.export.d": "Muat turun nota nuan dalam bentuk PDF atau teks biasa. Kongsi enggau tim atau simpan.",
    "features.analytics":"Analitik Rapat",
    "features.analytics.d":"Jejak tempoh, bilangan peserta, enggau kekerapan rapat. Nemu kemaya masa nuan digunaka.",

    // How it works
    "how.title":         "Bejalai dalam 60 saat",
    "how.sub":           "Tiga langkah mudah ngambika bot AI nuan bejalai.",
    "how.step1.title":   "Tampal pautan rapat",
    "how.step1.d":       "Salin URL Zoom atau Google Meet enggau tampal ke MeetingClone. 5 saat aja.",
    "how.step2.title":   "Sahka identiti bot nuan",
    "how.step2.d":       "Tetapka nama paparan bot enggau muat naik avatar ngambika peserta nemu sapa ia.",
    "how.step3.title":   "Terima nota nuan",
    "how.step3.d":       "Bot datai, rakam, enggau hantar transkripsi penuh enggau ringkasan AI enggau item tindakan.",

    // Pricing
    "pricing.title":     "Rega mudah enggau jujur",
    "pricing.sub":       "Satu pelan. Semua termasuk. Bulan pertama percuma sepenuhnya.",
    "pricing.plan":      "Pro Bulan",
    "pricing.free":      "🎉 Bulan pertama PERCUMA",
    "pricing.then":      "Kemudian $29/bulan. Batal bila-bila.",
    "pricing.cta":       "Mula percuma →",
    "pricing.note":      "Enda perlu kad kredit untuk percubaan percuma",

    // CTA section
    "cta.title":         "Masa nuan lebih berharga.",
    "cta.sub":           "Sertai profesional ti udah menuntut semula jadual nuan enggau MeetingClone.",
    "cta.btn":           "Mula bulan percuma nuan →",

    // Footer
    "footer.tagline":    "Kecerdasan rapat berkuasa AI untuk profesional moden.",
    "footer.rights":     "© 2026 MeetingClone oleh KOBIS Berhad. Hak cipta terpelihara.",

    // Dashboard
    "dash.title":        "Papan Pemuka",
    "dash.new":          "Rapat Baru",
    "dash.empty":        "Enda ada rapat lagi",
    "dash.empty.sub":    "Guna klon AI pertama nuan ke rapat ngambika mula.",

    // New meeting
    "meeting.title":     "Rapat Baru",
    "meeting.link.label":"Pautan Rapat",
    "meeting.link.ph":   "Tampal URL Zoom atau Google Meet…",
    "meeting.bot.name":  "Nama Paparan Bot",
    "meeting.bot.avatar":"Avatar Bot",
    "meeting.submit":    "Guna Klon AI",

    // General
    "general.loading":   "Muatka…",
    "general.error":     "Sesuatu salah",
    "general.save":      "Simpan perubahan",
    "general.cancel":    "Batal",
    "general.back":      "Balik",
  },
};

// ─── Context ─────────────────────────────────────────────────────────────────
interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType>({
  language: "en",
  setLanguage: () => {},
  t: (key) => key,
});

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => {
    return (localStorage.getItem("mc-lang") as Language) ?? "en";
  });

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem("mc-lang", lang);
  };

  const t = (key: string): string => {
    return translations[language][key] ?? translations["en"][key] ?? key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  return useContext(LanguageContext);
}
