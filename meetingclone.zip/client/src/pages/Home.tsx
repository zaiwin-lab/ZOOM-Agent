import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import { useLanguage } from "@/contexts/LanguageContext";
import { LanguageToggle } from "@/components/LanguageToggle";
import {
  Bot, Mic, FileText, Zap, Shield, Users, ChevronRight,
  CheckCircle2, ArrowRight, Sparkles, Clock, Search, Brain, Download
} from "lucide-react";

const LOGO_URL = "/manus-storage/kobis-logo_df6a415e.jpeg";

const PRICING_FEATURES_KEYS = [
  "Unlimited meetings per month",
  "Real-time transcription with speaker ID",
  "AI summaries, highlights & action items",
  "Full transcript search",
  "PDF & text export",
  "Custom bot name & avatar",
  "Meeting history & analytics",
  "Priority support",
];

export default function Home() {
  const { isAuthenticated } = useAuth();
  const [, navigate] = useLocation();
  const { t } = useLanguage();

  const FEATURES = [
    { icon: Bot,      titleKey: "features.join",       descKey: "features.join.d" },
    { icon: Mic,      titleKey: "features.transcript",  descKey: "features.transcript.d" },
    { icon: Brain,    titleKey: "features.summary",     descKey: "features.summary.d" },
    { icon: Search,   titleKey: "features.search",      descKey: "features.search.d" },
    { icon: Download, titleKey: "features.export",      descKey: "features.export.d" },
    { icon: Clock,    titleKey: "features.analytics",   descKey: "features.analytics.d" },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">

      {/* ── Navbar ─────────────────────────────────────────────────────── */}
      <nav className="fixed top-0 inset-x-0 z-50 border-b border-border/60 bg-white/90 backdrop-blur-xl shadow-sm">
        <div className="container flex items-center justify-between h-16">
          {/* Logo */}
          <a href="/" className="flex items-center gap-3 shrink-0">
            <img
              src={LOGO_URL}
              alt="KOBIS Berhad"
              className="h-9 w-auto object-contain"
              onError={(e) => {
                (e.target as HTMLImageElement).style.display = "none";
              }}
            />
            <div className="hidden sm:block border-l border-border pl-3">
              <p className="text-xs font-bold tracking-widest text-[oklch(0.48_0.16_240)] uppercase leading-none">MeetingClone</p>
              <p className="text-[10px] text-[oklch(0.64_0.13_72)] font-semibold tracking-wider leading-none mt-0.5">AI Meeting Intelligence</p>
            </div>
          </a>

          {/* Nav links */}
          <div className="hidden md:flex items-center gap-7 text-sm font-medium text-muted-foreground">
            <a href="#features"     className="hover:text-foreground transition-colors">{t("nav.features")}</a>
            <a href="#how-it-works" className="hover:text-foreground transition-colors">{t("nav.howItWorks")}</a>
            <a href="#pricing"      className="hover:text-foreground transition-colors">{t("nav.pricing")}</a>
          </div>

          {/* Right side: language + auth */}
          <div className="flex items-center gap-2">
            <LanguageToggle variant="navbar" />
            {isAuthenticated ? (
              <Button onClick={() => navigate("/dashboard")} size="sm" className="bg-[oklch(0.48_0.16_240)] hover:bg-[oklch(0.40_0.16_240)] text-white">
                {t("nav.dashboard")} <ArrowRight className="ml-1.5 w-3.5 h-3.5" />
              </Button>
            ) : (
              <>
                <Button variant="ghost" size="sm" asChild className="hidden sm:flex">
                  <a href={getLoginUrl()}>{t("nav.login")}</a>
                </Button>
                <Button size="sm" asChild className="bg-[oklch(0.48_0.16_240)] hover:bg-[oklch(0.40_0.16_240)] text-white">
                  <a href={getLoginUrl()}>Start free <ArrowRight className="ml-1.5 w-3.5 h-3.5" /></a>
                </Button>
              </>
            )}
          </div>
        </div>
      </nav>

      {/* ── Hero ───────────────────────────────────────────────────────── */}
      <section className="pt-28 pb-24 relative overflow-hidden bg-gradient-to-br from-[oklch(0.18_0.10_240)] via-[oklch(0.26_0.13_240)] to-[oklch(0.36_0.16_240)]">
        {/* Gold accent orbs */}
        <div className="absolute top-20 right-[10%] w-72 h-72 rounded-full bg-[oklch(0.64_0.13_72)]/15 blur-3xl pointer-events-none" />
        <div className="absolute top-60 left-[5%] w-48 h-48 rounded-full bg-[oklch(0.48_0.16_240)]/30 blur-2xl pointer-events-none" />

        <div className="container text-center relative">
          {/* Badge */}
          <div className="animate-fade-in mb-8">
            <Badge className="px-4 py-1.5 text-xs font-semibold tracking-widest uppercase bg-[oklch(0.64_0.13_72)] text-white border-0 shadow-md">
              <Sparkles className="w-3 h-3 mr-1.5" />
              {t("hero.badge")}
            </Badge>
          </div>

          {/* Main headline */}
          <h1 className="font-display font-900 text-4xl sm:text-5xl md:text-6xl lg:text-7xl text-white leading-[1.08] tracking-tight mb-4 animate-fade-up">
            {t("hero.tagline1")}<br />
            <span className="text-[oklch(0.72_0.13_72)]">{t("hero.tagline2")}</span>
          </h1>

          {/* AI tagline */}
          <p className="text-[oklch(0.72_0.13_72)] font-semibold text-sm tracking-widest uppercase mb-6 animate-fade-up delay-100">
            ✦ {t("hero.tagline.ai")} ✦
          </p>

          {/* Subheading */}
          <p className="text-[oklch(0.80_0.03_240)] text-lg md:text-xl max-w-2xl mx-auto leading-relaxed mb-10 animate-fade-up delay-200">
            {t("hero.sub")}
          </p>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8 animate-fade-up delay-300">
            <Button
              size="lg"
              asChild
              className="bg-[oklch(0.64_0.13_72)] hover:bg-[oklch(0.56_0.13_72)] text-white font-semibold px-8 h-12 shadow-lg hover:shadow-xl transition-all"
            >
              <a href={getLoginUrl()}>{t("hero.cta.start")}</a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              asChild
              className="border-white/30 text-white bg-white/10 hover:bg-white/20 backdrop-blur-sm h-12 px-8"
            >
              <a href="#how-it-works">{t("hero.cta.watch")}</a>
            </Button>
          </div>

          {/* Trust line */}
          <p className="text-[oklch(0.65_0.03_240)] text-sm animate-fade-up delay-400">
            {t("hero.trust")}
          </p>

          {/* KOBIS credential strip */}
          <div className="mt-14 flex flex-wrap items-center justify-center gap-6 animate-fade-up delay-500">
            {[
              { label: "Top 50 Koperasi Terbaik Sarawak", sub: "SKM Recognised" },
              { label: "10+ Years Active", sub: "Est. 2013" },
              { label: "ESG · AI · Innovation", sub: "KOBIS Berhad" },
            ].map((item) => (
              <div key={item.label} className="text-center px-5 py-3 rounded-xl bg-white/10 backdrop-blur-sm border border-white/15">
                <p className="text-white font-semibold text-sm">{item.label}</p>
                <p className="text-[oklch(0.72_0.13_72)] text-xs mt-0.5">{item.sub}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Features ───────────────────────────────────────────────────── */}
      <section id="features" className="py-24 bg-background">
        <div className="container">
          <div className="text-center mb-16">
            <p className="text-[oklch(0.64_0.13_72)] text-xs font-bold tracking-widest uppercase mb-3">Capabilities</p>
            <h2 className="font-display font-800 text-3xl md:text-4xl text-foreground mb-4">{t("features.title")}</h2>
            <p className="text-muted-foreground text-lg max-w-xl mx-auto">{t("features.sub")}</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {FEATURES.map(({ icon: Icon, titleKey, descKey }, i) => (
              <div
                key={titleKey}
                className={`group p-6 rounded-2xl border border-border bg-card hover:shadow-lg transition-all duration-300 hover:-translate-y-1 animate-fade-up`}
                style={{ animationDelay: `${i * 80}ms` }}
              >
                <div className="w-11 h-11 rounded-xl bg-[oklch(0.93_0.04_240)] flex items-center justify-center mb-4 group-hover:bg-[oklch(0.48_0.16_240)] transition-colors">
                  <Icon className="w-5 h-5 text-[oklch(0.48_0.16_240)] group-hover:text-white transition-colors" />
                </div>
                <h3 className="font-display font-700 text-base mb-2 text-foreground">{t(titleKey)}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{t(descKey)}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── How it works ───────────────────────────────────────────────── */}
      <section id="how-it-works" className="py-24 bg-[oklch(0.97_0.01_240)]">
        <div className="container">
          <div className="text-center mb-16">
            <p className="text-[oklch(0.64_0.13_72)] text-xs font-bold tracking-widest uppercase mb-3">Process</p>
            <h2 className="font-display font-800 text-3xl md:text-4xl text-foreground mb-4">{t("how.title")}</h2>
            <p className="text-muted-foreground text-lg max-w-xl mx-auto">{t("how.sub")}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {[
              { step: "01", titleKey: "how.step1.title", descKey: "how.step1.d", icon: Zap },
              { step: "02", titleKey: "how.step2.title", descKey: "how.step2.d", icon: Users },
              { step: "03", titleKey: "how.step3.title", descKey: "how.step3.d", icon: FileText },
            ].map(({ step, titleKey, descKey, icon: Icon }) => (
              <div key={step} className="relative text-center p-8 rounded-2xl bg-white border border-border shadow-sm">
                <div className="w-14 h-14 rounded-2xl bg-[oklch(0.20_0.10_240)] flex items-center justify-center mx-auto mb-5">
                  <Icon className="w-6 h-6 text-[oklch(0.72_0.13_72)]" />
                </div>
                <div className="absolute top-4 right-4 text-5xl font-black text-[oklch(0.93_0.04_240)] select-none leading-none">{step}</div>
                <h3 className="font-display font-700 text-lg mb-3 text-foreground">{t(titleKey)}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{t(descKey)}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Pricing ────────────────────────────────────────────────────── */}
      <section id="pricing" className="py-24 bg-background">
        <div className="container">
          <div className="text-center mb-16">
            <p className="text-[oklch(0.64_0.13_72)] text-xs font-bold tracking-widest uppercase mb-3">Pricing</p>
            <h2 className="font-display font-800 text-3xl md:text-4xl text-foreground mb-4">{t("pricing.title")}</h2>
            <p className="text-muted-foreground text-lg max-w-xl mx-auto">{t("pricing.sub")}</p>
          </div>

          <div className="max-w-md mx-auto">
            <div className="relative rounded-3xl border-2 border-[oklch(0.48_0.16_240)] bg-white shadow-2xl overflow-hidden">
              {/* Top banner */}
              <div className="bg-gradient-to-r from-[oklch(0.20_0.10_240)] to-[oklch(0.38_0.16_240)] px-8 py-5 text-center">
                <p className="text-[oklch(0.72_0.13_72)] text-xs font-bold tracking-widest uppercase mb-1">{t("pricing.plan")}</p>
                <div className="flex items-end justify-center gap-1">
                  <span className="text-5xl font-black text-white font-display">$29</span>
                  <span className="text-white/70 text-base mb-2">/month</span>
                </div>
                <div className="mt-3 inline-flex items-center gap-2 bg-[oklch(0.64_0.13_72)] text-white text-sm font-bold px-5 py-2 rounded-full">
                  <Sparkles className="w-3.5 h-3.5" />
                  {t("pricing.free")}
                </div>
              </div>

              <div className="p-8">
                <ul className="space-y-3 mb-8">
                  {PRICING_FEATURES_KEYS.map((feat) => (
                    <li key={feat} className="flex items-center gap-3 text-sm text-foreground">
                      <CheckCircle2 className="w-4 h-4 text-[oklch(0.48_0.16_240)] shrink-0" />
                      {feat}
                    </li>
                  ))}
                </ul>

                <Button
                  size="lg"
                  className="w-full h-12 bg-[oklch(0.48_0.16_240)] hover:bg-[oklch(0.40_0.16_240)] text-white font-semibold text-base shadow-lg"
                  asChild
                >
                  <a href={getLoginUrl()}>{t("pricing.cta")}</a>
                </Button>

                <p className="text-center text-xs text-muted-foreground mt-4">{t("pricing.note")}</p>
                <p className="text-center text-xs text-muted-foreground mt-1">{t("pricing.then")}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── CTA Banner ─────────────────────────────────────────────────── */}
      <section className="py-20 bg-gradient-to-br from-[oklch(0.20_0.10_240)] via-[oklch(0.28_0.13_240)] to-[oklch(0.38_0.16_240)]">
        <div className="container text-center">
          <h2 className="font-display font-800 text-3xl md:text-4xl text-white mb-4">{t("cta.title")}</h2>
          <p className="text-[oklch(0.80_0.03_240)] text-lg max-w-xl mx-auto mb-8">{t("cta.sub")}</p>
          <Button
            size="lg"
            asChild
            className="bg-[oklch(0.64_0.13_72)] hover:bg-[oklch(0.56_0.13_72)] text-white font-semibold px-10 h-12 shadow-xl"
          >
            <a href={getLoginUrl()}>{t("cta.btn")}</a>
          </Button>
        </div>
      </section>

      {/* ── Footer ─────────────────────────────────────────────────────── */}
      <footer className="py-12 border-t border-border bg-background">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            {/* Logo + tagline */}
            <div className="flex flex-col items-center md:items-start gap-2">
              <img
                src={LOGO_URL}
                alt="KOBIS Berhad"
                className="h-8 w-auto object-contain"
                onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
              />
              <p className="text-muted-foreground text-sm">{t("footer.tagline")}</p>
            </div>

            {/* Language toggle in footer */}
            <div className="flex flex-col items-center gap-2">
              <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Language</p>
              <LanguageToggle variant="compact" />
            </div>

            {/* Links */}
            <div className="flex flex-col items-center md:items-end gap-1">
              <p className="text-muted-foreground text-xs">{t("footer.rights")}</p>
              <p className="text-muted-foreground text-xs">Management · Investment · Consultancy</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
