import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { useEffect } from "react";
import {
  Users, Calendar, CheckCircle2, CreditCard, Loader2,
  TrendingUp, Shield, AlertCircle
} from "lucide-react";
import { format } from "date-fns";

export default function AdminDashboard() {
  const { user, isAuthenticated, loading } = useAuth();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (!loading && isAuthenticated && user?.role !== "admin") {
      navigate("/dashboard");
    }
  }, [loading, isAuthenticated, user]);

  const { data: stats, isLoading: statsLoading } = trpc.admin.stats.useQuery(undefined, {
    enabled: user?.role === "admin",
  });
  const { data: users, isLoading: usersLoading } = trpc.admin.users.useQuery(undefined, {
    enabled: user?.role === "admin",
  });

  if (loading || statsLoading) {
    return (
      <AppLayout title="Admin Dashboard">
        <div className="flex items-center justify-center py-24">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      </AppLayout>
    );
  }

  if (user?.role !== "admin") return null;

  return (
    <AppLayout title="Admin Dashboard">
      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-2 mb-1">
          <Shield className="w-5 h-5 text-primary" />
          <h2 className="font-display text-2xl font-700 tracking-tight">Admin Dashboard</h2>
        </div>
        <p className="text-muted-foreground text-sm">Platform overview and user management.</p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          { label: "Total Users", value: stats?.totalUsers ?? 0, icon: Users, color: "text-blue-600 bg-blue-50 dark:bg-blue-900/20" },
          { label: "Total Meetings", value: stats?.totalMeetings ?? 0, icon: Calendar, color: "text-purple-600 bg-purple-50 dark:bg-purple-900/20" },
          { label: "Completed", value: stats?.completedMeetings ?? 0, icon: CheckCircle2, color: "text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20" },
          { label: "Active Subscriptions", value: stats?.activeSubscriptions ?? 0, icon: CreditCard, color: "text-amber-600 bg-amber-50 dark:bg-amber-900/20" },
        ].map((stat) => (
          <div key={stat.label} className="rounded-xl border border-border/60 bg-card p-4">
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${stat.color}`}>
              <stat.icon className="w-4 h-4" />
            </div>
            <div className="font-display font-700 text-2xl">{stat.value}</div>
            <div className="text-xs text-muted-foreground mt-0.5">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Users table */}
      <div className="rounded-xl border border-border/60 bg-card overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border/40">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-muted-foreground" />
            <h3 className="font-display font-600 text-sm">All Users</h3>
          </div>
          <Badge variant="secondary" className="text-xs">{users?.length ?? 0} total</Badge>
        </div>

        {usersLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
          </div>
        ) : users?.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <AlertCircle className="w-8 h-8 text-muted-foreground mb-3" />
            <p className="text-sm text-muted-foreground">No users yet.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border/40 bg-muted/20">
                  <th className="text-left px-5 py-3 text-xs font-600 text-muted-foreground uppercase tracking-wide">User</th>
                  <th className="text-left px-4 py-3 text-xs font-600 text-muted-foreground uppercase tracking-wide">Role</th>
                  <th className="text-left px-4 py-3 text-xs font-600 text-muted-foreground uppercase tracking-wide">Plan</th>
                  <th className="text-left px-4 py-3 text-xs font-600 text-muted-foreground uppercase tracking-wide">Status</th>
                  <th className="text-right px-4 py-3 text-xs font-600 text-muted-foreground uppercase tracking-wide">Meetings</th>
                  <th className="text-left px-4 py-3 text-xs font-600 text-muted-foreground uppercase tracking-wide">Joined</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/30">
                {users?.map((u) => (
                  <tr key={u.id} className="hover:bg-muted/20 transition-colors">
                    <td className="px-5 py-3.5">
                      <div>
                        <p className="font-medium text-sm">{u.displayName ?? u.name ?? "—"}</p>
                        <p className="text-xs text-muted-foreground">{u.email ?? "—"}</p>
                      </div>
                    </td>
                    <td className="px-4 py-3.5">
                      <Badge variant="secondary" className={`text-xs capitalize ${u.role === "admin" ? "bg-primary/10 text-primary" : ""}`}>
                        {u.role}
                      </Badge>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs capitalize">
                        {u.subscription?.plan === "monthly" ? "Pro" : u.subscription?.plan === "free_trial" ? "Trial" : "—"}
                      </span>
                    </td>
                    <td className="px-4 py-3.5">
                      {u.subscription ? (
                        <Badge
                          className={`text-xs px-2 py-0.5 border-0 font-500 ${
                            u.subscription.status === "active" ? "status-completed" :
                            u.subscription.status === "cancelled" ? "status-failed" : "status-pending"
                          }`}
                        >
                          {u.subscription.status}
                        </Badge>
                      ) : (
                        <span className="text-xs text-muted-foreground">—</span>
                      )}
                    </td>
                    <td className="px-4 py-3.5 text-right">
                      <span className="font-display font-600 text-sm">{u.meetingCount}</span>
                    </td>
                    <td className="px-4 py-3.5">
                      <span className="text-xs text-muted-foreground">
                        {format(new Date(u.createdAt), "MMM d, yyyy")}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
