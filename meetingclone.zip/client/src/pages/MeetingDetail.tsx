import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { useParams } from "wouter";
import {
  Loader2, Search, Download, FileText, Sparkles, CheckSquare,
  Clock, Users, Bot, RefreshCw, ChevronRight, AlertCircle
} from "lucide-react";
import { useState, useMemo } from "react";
import { formatDistanceToNow, format } from "date-fns";
import { Streamdown } from "streamdown";

const STATUS_CONFIG: Record<string, { label: string; className: string }> = {
  pending:    { label: "Pending",    className: "status-pending" },
  joining:    { label: "Joining",    className: "status-joining" },
  recording:  { label: "Recording", className: "status-recording" },
  processing: { label: "Processing",className: "status-processing" },
  completed:  { label: "Completed", className: "status-completed" },
  failed:     { label: "Failed",    className: "status-failed" },
};

export default function MeetingDetail() {
  const params = useParams<{ id: string }>();
  const meetingId = parseInt(params.id ?? "0");
  const [searchQuery, setSearchQuery] = useState("");
  const utils = trpc.useUtils();

  const { data, isLoading, refetch } = trpc.meetings.get.useQuery({ id: meetingId }, { refetchInterval: (data) => {
    const status = data?.state?.data?.meeting?.status;
    if (status === "recording" || status === "joining" || status === "processing") return 5000;
    return false;
  }});

  const processNotes = trpc.meetings.processNotes.useMutation({
    onSuccess: () => {
      toast.success("AI processing started!");
      refetch();
    },
    onError: (err) => toast.error("Processing failed", { description: err.message }),
  });

  const { meeting, notes, transcripts } = data ?? {};

  const filteredTranscripts = useMemo(() => {
    if (!searchQuery.trim() || !transcripts) return transcripts ?? [];
    const q = searchQuery.toLowerCase();
    return transcripts.filter((t) =>
      t.content.toLowerCase().includes(q) || (t.speaker ?? "").toLowerCase().includes(q)
    );
  }, [transcripts, searchQuery]);

  const highlights = useMemo(() => {
    try { return JSON.parse(notes?.highlights ?? "[]") as string[]; } catch { return []; }
  }, [notes?.highlights]);

  const actionItems = useMemo(() => {
    try { return JSON.parse(notes?.actionItems ?? "[]") as { task: string; assignee: string | null; dueDate: string | null }[]; } catch { return []; }
  }, [notes?.actionItems]);

  const handleExportText = () => {
    if (!meeting || !transcripts) return;
    const lines = [
      `Meeting Notes — ${meeting.title ?? "Meeting"}`,
      `Date: ${format(new Date(meeting.createdAt), "PPP")}`,
      `Duration: ${meeting.durationFormatted ?? "—"}`,
      `Participants: ${meeting.participantCount ?? "—"}`,
      "",
      "── SUMMARY ──────────────────────────────────────────",
      notes?.summary ?? "No summary available.",
      "",
      "── KEY HIGHLIGHTS ───────────────────────────────────",
      ...highlights.map((h, i) => `${i + 1}. ${h}`),
      "",
      "── ACTION ITEMS ─────────────────────────────────────",
      ...actionItems.map((a, i) => `${i + 1}. ${a.task}${a.assignee ? ` (${a.assignee})` : ""}${a.dueDate ? ` — Due: ${a.dueDate}` : ""}`),
      "",
      "── FULL TRANSCRIPT ──────────────────────────────────",
      ...transcripts.map((t) => `[${t.speaker ?? "Speaker"}]: ${t.content}`),
    ];
    const blob = new Blob([lines.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `meeting-notes-${meetingId}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Notes exported as text file");
  };

  const handleExportPdf = () => {
    if (!meeting || !transcripts) return;
    const lines = [
      `<html><head><meta charset="utf-8"><style>
        body{font-family:system-ui,sans-serif;max-width:800px;margin:40px auto;padding:0 20px;color:#111;line-height:1.6}
        h1{font-size:24px;font-weight:700;margin-bottom:4px}
        .meta{color:#666;font-size:13px;margin-bottom:32px}
        h2{font-size:14px;font-weight:600;text-transform:uppercase;letter-spacing:.05em;color:#555;margin:28px 0 12px;padding-bottom:6px;border-bottom:1px solid #e5e7eb}
        p{margin:0 0 8px}
        .item{margin-bottom:8px;padding-left:16px;position:relative}
        .item::before{content:"•";position:absolute;left:0;color:#6366f1}
        .transcript-entry{margin-bottom:12px}
        .speaker{font-weight:600;font-size:13px;color:#6366f1}
        .content{font-size:14px;color:#374151}
        .action{background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px;padding:10px 14px;margin-bottom:8px}
        .action-task{font-weight:500;font-size:14px}
        .action-meta{font-size:12px;color:#9ca3af;margin-top:2px}
      </style></head><body>`,
      `<h1>${meeting.title ?? "Meeting Notes"}</h1>`,
      `<div class="meta">Date: ${format(new Date(meeting.createdAt), "PPP")} &nbsp;·&nbsp; Duration: ${meeting.durationFormatted ?? "—"} &nbsp;·&nbsp; Participants: ${meeting.participantCount ?? "—"}</div>`,
      notes?.summary ? `<h2>Summary</h2><p>${notes.summary}</p>` : "",
      highlights.length > 0 ? `<h2>Key Highlights</h2>${highlights.map((h) => `<div class="item">${h}</div>`).join("")}` : "",
      actionItems.length > 0 ? `<h2>Action Items</h2>${actionItems.map((a) => `<div class="action"><div class="action-task">${a.task}</div><div class="action-meta">${[a.assignee, a.dueDate ? `Due: ${a.dueDate}` : ""].filter(Boolean).join(" · ")}</div></div>`).join("")}` : "",
      `<h2>Full Transcript</h2>`,
      ...transcripts.map((t) => `<div class="transcript-entry"><div class="speaker">${t.speaker ?? "Speaker"}</div><div class="content">${t.content}</div></div>`),
      `</body></html>`,
    ];
    const blob = new Blob([lines.join("\n")], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const win = window.open(url, "_blank");
    if (win) { win.onload = () => { win.print(); URL.revokeObjectURL(url); }; }
    toast.success("Opening print dialog for PDF export");
  };

  if (isLoading) {
    return (
      <AppLayout title="Meeting">
        <div className="flex items-center justify-center py-24">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      </AppLayout>
    );
  }

  if (!meeting) {
    return (
      <AppLayout title="Meeting Not Found">
        <div className="flex flex-col items-center justify-center py-24 text-center">
          <AlertCircle className="w-10 h-10 text-muted-foreground mb-4" />
          <h3 className="font-display font-600 text-lg mb-2">Meeting not found</h3>
          <p className="text-muted-foreground text-sm">This meeting may have been deleted or you don't have access.</p>
        </div>
      </AppLayout>
    );
  }

  const statusCfg = STATUS_CONFIG[meeting.status] ?? STATUS_CONFIG.pending;
  const isLive = meeting.status === "recording" || meeting.status === "joining";
  const isProcessing = meeting.status === "processing" || notes?.processingStatus === "processing";

  return (
    <AppLayout title="Meeting Notes">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <Badge className={`text-xs px-2.5 py-0.5 border-0 font-500 ${statusCfg.className}`}>
                {isLive && <span className="w-1.5 h-1.5 rounded-full bg-current mr-1.5 animate-pulse inline-block" />}
                {statusCfg.label}
              </Badge>
              <Badge variant="secondary" className="text-xs">
                {meeting.platform === "zoom" ? "Zoom" : meeting.platform === "google_meet" ? "Google Meet" : "Meeting"}
              </Badge>
            </div>
            <h2 className="font-display text-xl font-700 tracking-tight">
              {meeting.title ?? "Meeting Recording"}
            </h2>
            <div className="flex items-center gap-4 text-sm text-muted-foreground mt-1">
              <span>{format(new Date(meeting.createdAt), "PPP")}</span>
              {meeting.durationFormatted && (
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" /> {meeting.durationFormatted}
                </span>
              )}
              {meeting.participantCount && (
                <span className="flex items-center gap-1">
                  <Users className="w-3.5 h-3.5" /> {meeting.participantCount} participants
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            <button
              onClick={() => refetch()}
              className="p-2 rounded-lg hover:bg-accent transition-colors text-muted-foreground"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            {meeting.status === "completed" && (
              <>
                <Button variant="outline" size="sm" onClick={handleExportText}>
                  <Download className="w-3.5 h-3.5 mr-1.5" /> TXT
                </Button>
                <Button variant="outline" size="sm" onClick={handleExportPdf}>
                  <FileText className="w-3.5 h-3.5 mr-1.5" /> PDF
                </Button>
              </>
            )}
          </div>
        </div>

        {/* Live status */}
        {isLive && (
          <div className="flex items-center gap-3 rounded-xl border border-red-200 bg-red-50 dark:border-red-800/40 dark:bg-red-900/10 p-4">
            <div className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse flex-shrink-0" />
            <div>
              <p className="text-sm font-medium text-red-700 dark:text-red-400">
                {meeting.status === "joining" ? "Bot is joining the meeting…" : "Recording in progress"}
              </p>
              <p className="text-xs text-red-600/70 dark:text-red-400/70">This page will update automatically.</p>
            </div>
          </div>
        )}

        {/* Processing status */}
        {isProcessing && !isLive && (
          <div className="flex items-center gap-3 rounded-xl border border-purple-200 bg-purple-50 dark:border-purple-800/40 dark:bg-purple-900/10 p-4">
            <Loader2 className="w-4 h-4 text-purple-600 animate-spin flex-shrink-0" />
            <div>
              <p className="text-sm font-medium text-purple-700 dark:text-purple-400">AI is processing your meeting notes…</p>
              <p className="text-xs text-purple-600/70 dark:text-purple-400/70">Summary, highlights, and action items will appear shortly.</p>
            </div>
          </div>
        )}

        {/* Process button */}
        {meeting.status === "completed" && !notes?.summary && notes?.processingStatus !== "processing" && (transcripts?.length ?? 0) > 0 && (
          <div className="flex items-center gap-3 rounded-xl border border-border/60 bg-muted/30 p-4">
            <Sparkles className="w-4 h-4 text-primary flex-shrink-0" />
            <div className="flex-1">
              <p className="text-sm font-medium">Generate AI notes</p>
              <p className="text-xs text-muted-foreground">Extract summary, highlights, and action items from the transcript.</p>
            </div>
            <Button size="sm" onClick={() => processNotes.mutate({ meetingId })} disabled={processNotes.isPending}>
              {processNotes.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5 mr-1.5" />}
              Generate
            </Button>
          </div>
        )}
      </div>

      {/* Content tabs */}
      {(meeting.status === "completed" || (transcripts?.length ?? 0) > 0) ? (
        <Tabs defaultValue="summary" className="space-y-4">
          <TabsList className="h-9">
            <TabsTrigger value="summary" className="text-xs">Summary</TabsTrigger>
            <TabsTrigger value="highlights" className="text-xs">Highlights</TabsTrigger>
            <TabsTrigger value="actions" className="text-xs">Action Items</TabsTrigger>
            <TabsTrigger value="transcript" className="text-xs">Transcript</TabsTrigger>
          </TabsList>

          {/* Summary */}
          <TabsContent value="summary">
            <div className="rounded-xl border border-border/60 bg-card p-6">
              <div className="flex items-center gap-2 mb-4">
                <Sparkles className="w-4 h-4 text-primary" />
                <h3 className="font-display font-600 text-sm">AI Summary</h3>
              </div>
              {notes?.summary ? (
                <div className="prose prose-sm dark:prose-invert max-w-none">
                  <Streamdown>{notes.summary}</Streamdown>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground italic">
                  {isProcessing ? "Generating summary…" : "No summary available yet."}
                </p>
              )}
            </div>
          </TabsContent>

          {/* Highlights */}
          <TabsContent value="highlights">
            <div className="rounded-xl border border-border/60 bg-card p-6">
              <div className="flex items-center gap-2 mb-4">
                <ChevronRight className="w-4 h-4 text-primary" />
                <h3 className="font-display font-600 text-sm">Key Highlights</h3>
              </div>
              {highlights.length > 0 ? (
                <div className="space-y-3">
                  {highlights.map((h, i) => (
                    <div key={i} className="flex items-start gap-3 p-3 rounded-lg bg-muted/30 border border-border/40">
                      <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="text-[10px] font-700 text-primary">{i + 1}</span>
                      </div>
                      <p className="text-sm leading-relaxed">{h}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground italic">
                  {isProcessing ? "Extracting highlights…" : "No highlights available yet."}
                </p>
              )}
            </div>
          </TabsContent>

          {/* Action Items */}
          <TabsContent value="actions">
            <div className="rounded-xl border border-border/60 bg-card p-6">
              <div className="flex items-center gap-2 mb-4">
                <CheckSquare className="w-4 h-4 text-primary" />
                <h3 className="font-display font-600 text-sm">Action Items</h3>
              </div>
              {actionItems.length > 0 ? (
                <div className="space-y-3">
                  {actionItems.map((item, i) => (
                    <div key={i} className="flex items-start gap-3 p-4 rounded-xl border border-border/60 bg-background hover:border-primary/30 transition-colors">
                      <div className="w-5 h-5 rounded border-2 border-primary/40 flex-shrink-0 mt-0.5" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium">{item.task}</p>
                        <div className="flex items-center gap-3 mt-1">
                          {item.assignee && (
                            <span className="text-xs text-muted-foreground">
                              👤 {item.assignee}
                            </span>
                          )}
                          {item.dueDate && (
                            <span className="text-xs text-muted-foreground">
                              📅 {item.dueDate}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground italic">
                  {isProcessing ? "Extracting action items…" : "No action items found."}
                </p>
              )}
            </div>
          </TabsContent>

          {/* Transcript */}
          <TabsContent value="transcript">
            <div className="rounded-xl border border-border/60 bg-card overflow-hidden">
              {/* Search */}
              <div className="px-5 py-4 border-b border-border/40">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Search transcript…"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9 h-9 text-sm"
                  />
                </div>
                {searchQuery && (
                  <p className="text-xs text-muted-foreground mt-2">
                    {filteredTranscripts.length} result{filteredTranscripts.length !== 1 ? "s" : ""} for "{searchQuery}"
                  </p>
                )}
              </div>

              {/* Transcript entries */}
              <div className="divide-y divide-border/30 max-h-[600px] overflow-y-auto">
                {filteredTranscripts.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-center">
                    <Search className="w-8 h-8 text-muted-foreground mb-3" />
                    <p className="text-sm text-muted-foreground">
                      {searchQuery ? "No results found." : "No transcript available yet."}
                    </p>
                  </div>
                ) : (
                  filteredTranscripts.map((t, i) => {
                    const highlight = searchQuery && t.content.toLowerCase().includes(searchQuery.toLowerCase());
                    return (
                      <div key={t.id ?? i} className={`px-5 py-4 ${highlight ? "bg-amber-50/50 dark:bg-amber-900/10" : ""}`}>
                        <div className="flex items-center gap-2 mb-1.5">
                          <span className="text-xs font-600 text-primary">{t.speaker ?? "Speaker"}</span>
                          {t.startTimeSeconds != null && (
                            <span className="text-[10px] text-muted-foreground font-mono">
                              {Math.floor(t.startTimeSeconds / 60)}:{String(t.startTimeSeconds % 60).padStart(2, "0")}
                            </span>
                          )}
                        </div>
                        <p className="text-sm leading-relaxed text-foreground/90">{t.content}</p>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      ) : (
        <div className="rounded-xl border border-border/60 bg-card flex flex-col items-center justify-center py-16 text-center">
          <div className="w-14 h-14 rounded-2xl bg-muted flex items-center justify-center mb-4 animate-float">
            <Bot className="w-7 h-7 text-muted-foreground" />
          </div>
          <h4 className="font-display font-600 text-base mb-2">
            {isLive ? "Meeting in progress…" : "Waiting for meeting data"}
          </h4>
          <p className="text-sm text-muted-foreground max-w-xs">
            {isLive
              ? "Your bot is attending the meeting. Notes will appear here when it's done."
              : "The meeting hasn't started yet or the bot is still connecting."}
          </p>
        </div>
      )}
    </AppLayout>
  );
}
