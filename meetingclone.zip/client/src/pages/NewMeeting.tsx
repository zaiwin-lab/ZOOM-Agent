import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { useState, useRef } from "react";
import { Bot, Link2, Upload, Loader2, CheckCircle2, AlertCircle, Zap } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";

function detectPlatform(url: string): string {
  if (url.includes("zoom.us") || url.includes("zoom.com")) return "Zoom";
  if (url.includes("meet.google.com")) return "Google Meet";
  if (url.includes("teams.microsoft.com")) return "Microsoft Teams";
  return "";
}

export default function NewMeeting() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { data: profile } = trpc.profile.get.useQuery();

  const [meetingUrl, setMeetingUrl] = useState("");
  const [botName, setBotName] = useState(profile?.user?.displayName ?? user?.name ?? "AI Assistant");
  const [avatarPreview, setAvatarPreview] = useState<string | null>(profile?.user?.avatarUrl ?? null);
  const [avatarBase64, setAvatarBase64] = useState<string | null>(null);
  const [avatarMime, setAvatarMime] = useState<string>("image/jpeg");
  const [step, setStep] = useState<"link" | "configure" | "deploying">("link");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const platform = detectPlatform(meetingUrl);

  const createMeeting = trpc.meetings.create.useMutation({
    onSuccess: (data) => {
      toast.success("Bot deployed successfully!", {
        description: "Your AI clone is joining the meeting.",
      });
      navigate(`/meetings/${data.meetingId}`);
    },
    onError: (err) => {
      toast.error("Failed to deploy bot", { description: err.message });
      setStep("configure");
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      toast.error("Image too large", { description: "Please use an image under 2MB." });
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      const dataUrl = ev.target?.result as string;
      const base64 = dataUrl.split(",")[1];
      setAvatarPreview(dataUrl);
      setAvatarBase64(base64);
      setAvatarMime(file.type);
    };
    reader.readAsDataURL(file);
  };

  const handleDeploy = () => {
    if (!botName.trim()) {
      toast.error("Please enter a bot name.");
      return;
    }
    setStep("deploying");
    createMeeting.mutate({
      meetingUrl,
      botName: botName.trim(),
      botAvatarBase64: avatarBase64 ?? undefined,
      botAvatarMime: avatarMime,
    });
  };

  const isValidUrl = meetingUrl.startsWith("http") && (
    meetingUrl.includes("zoom") || meetingUrl.includes("meet.google") || meetingUrl.includes("teams.microsoft")
  );

  return (
    <AppLayout title="New Meeting">
      <div className="max-w-xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h2 className="font-display text-2xl font-700 tracking-tight mb-1">Deploy your AI clone</h2>
          <p className="text-muted-foreground text-sm">
            Paste a meeting link and configure your bot. It'll join, record, and take notes for you.
          </p>
        </div>

        {/* Step 1: Meeting link */}
        <div className={`rounded-xl border bg-card p-6 mb-4 transition-all ${step !== "link" ? "opacity-60" : "border-primary/40 shadow-sm shadow-primary/10"}`}>
          <div className="flex items-center gap-3 mb-4">
            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-700 ${step !== "link" ? "bg-emerald-500 text-white" : "bg-primary text-primary-foreground"}`}>
              {step !== "link" ? <CheckCircle2 className="w-4 h-4" /> : "1"}
            </div>
            <h3 className="font-display font-600 text-base">Meeting link</h3>
          </div>

          <div className="space-y-3">
            <div className="relative">
              <Link2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="https://zoom.us/j/... or https://meet.google.com/..."
                value={meetingUrl}
                onChange={(e) => setMeetingUrl(e.target.value)}
                className="pl-9 h-11"
                disabled={step !== "link"}
              />
            </div>

            {meetingUrl && !isValidUrl && (
              <div className="flex items-center gap-2 text-xs text-amber-600">
                <AlertCircle className="w-3.5 h-3.5" />
                Please enter a valid Zoom, Google Meet, or Teams link.
              </div>
            )}

            {platform && (
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs">
                  ✓ {platform} detected
                </Badge>
              </div>
            )}

            {step === "link" && (
              <Button
                className="w-full"
                disabled={!isValidUrl}
                onClick={() => setStep("configure")}
              >
                Continue <CheckCircle2 className="ml-2 w-4 h-4" />
              </Button>
            )}
          </div>
        </div>

        {/* Step 2: Configure bot */}
        <div className={`rounded-xl border bg-card p-6 mb-4 transition-all ${step === "link" ? "opacity-40 pointer-events-none" : step === "configure" ? "border-primary/40 shadow-sm shadow-primary/10" : "opacity-60"}`}>
          <div className="flex items-center gap-3 mb-5">
            <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-700 ${step === "deploying" ? "bg-emerald-500 text-white" : "bg-primary text-primary-foreground"}`}>
              {step === "deploying" ? <CheckCircle2 className="w-4 h-4" /> : "2"}
            </div>
            <h3 className="font-display font-600 text-base">Configure your bot</h3>
          </div>

          <div className="space-y-5">
            {/* Avatar */}
            <div className="flex items-center gap-4">
              <div className="relative">
                <Avatar className="w-16 h-16 border-2 border-border">
                  <AvatarImage src={avatarPreview ?? undefined} />
                  <AvatarFallback className="bg-primary/10 text-primary font-700 text-lg">
                    {botName.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-sm hover:bg-primary/90 transition-colors"
                >
                  <Upload className="w-3 h-3" />
                </button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileChange}
                />
              </div>
              <div>
                <p className="text-sm font-medium mb-0.5">Bot avatar</p>
                <p className="text-xs text-muted-foreground">This photo will be shown to other participants.</p>
                <button
                  onClick={() => fileInputRef.current?.click()}
                  className="text-xs text-primary hover:underline mt-1"
                >
                  Upload photo
                </button>
              </div>
            </div>

            {/* Bot name */}
            <div className="space-y-1.5">
              <Label htmlFor="botName" className="text-sm font-medium">Display name</Label>
              <Input
                id="botName"
                value={botName}
                onChange={(e) => setBotName(e.target.value)}
                placeholder="e.g. Alex's AI Assistant"
                className="h-11"
                maxLength={128}
              />
              <p className="text-xs text-muted-foreground">
                This name will appear in the meeting participants list.
              </p>
            </div>

            {/* Preview */}
            <div className="rounded-lg bg-muted/40 border border-border/60 p-4">
              <p className="text-xs font-medium text-muted-foreground mb-3 uppercase tracking-wide">Preview</p>
              <div className="flex items-center gap-3">
                <Avatar className="w-9 h-9">
                  <AvatarImage src={avatarPreview ?? undefined} />
                  <AvatarFallback className="bg-primary/10 text-primary font-700 text-sm">
                    {botName.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium">{botName || "Your Bot Name"}</p>
                  <p className="text-xs text-muted-foreground">AI Meeting Assistant</p>
                </div>
                <Badge variant="secondary" className="ml-auto text-xs">Bot</Badge>
              </div>
            </div>

            {step === "configure" && (
              <Button className="w-full h-11 font-600" onClick={handleDeploy}>
                <Zap className="mr-2 w-4 h-4" />
                Deploy bot to meeting
              </Button>
            )}
          </div>
        </div>

        {/* Step 3: Deploying */}
        {step === "deploying" && (
          <div className="rounded-xl border border-primary/40 bg-card p-8 text-center animate-fade-up">
            <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4 animate-float">
              <Bot className="w-7 h-7 text-primary" />
            </div>
            <h3 className="font-display font-600 text-lg mb-2">Deploying your clone…</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Your AI bot is joining the meeting. This usually takes 10–30 seconds.
            </p>
            <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="w-4 h-4 animate-spin" />
              Connecting to meeting
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
