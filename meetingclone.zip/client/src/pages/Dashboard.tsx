import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";
import { Plus, Bot, Clock, Users, FileText, ArrowRight, Calendar, Loader2, RefreshCw } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

const STATUS_CONFIG: Record<string, { label: string; className: string }> = {
  pending:    { label: "Pending",    className: "status-pending" },
  joining:    { label: "Joining",    className: "status-joining" },
  recording:  { label: "Recording", className: "status-recording" },
  processing: { label: "Processing",className: "status-processing" },
  completed:  { label: "Completed", className: "status-completed" },
  failed:     { label: "Failed",    className: "status-failed" },
};

const PLATFORM_LABELS: Record<string, string> = {
  zoom: "Zoom", google_meet: "Google Meet", teams: "Teams", other: "Meeting",
};

export default function Dashboard() {
  const [, navigate] = useLocation();
  const { data: meetings, isLoading, refetch } = trpc.meetings.list.useQuery();
  const { data: profile } = trpc.profile.get.useQuery();

  const totalMeetings = meetings?.length ?? 0;
  const completedMeetings = meetings?.filter((m) => m.status === "completed").length ?? 0;
  const totalMinutes = meetings?.reduce((acc, m) => acc + (m.durationSeconds ?? 0) / 60, 0) ?? 0;

  return (
    <AppLayout title="Dashboard">
      {/* Welcome + stats */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="font-display text-2xl font-700 tracking-tight">
              Welcome back, {profile?.user?.displayName ?? "there"} 👋
            </h2>
            <p className="text-muted-foreground text-sm mt-1">Here's an overview of your meeting activity.</p>
          </div>
          <Button onClick={() => navigate("/meetings/new")}>
            <Plus className="w-4 h-4 mr-2" /> New Meeting
          </Button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: "Total Meetings", value: totalMeetings, icon: Calendar, color: "text-blue-600 bg-blue-50 dark:bg-blue-900/20" },
            { label: "Completed", value: completedMeetings, icon: FileText, color: "text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20" },
            { label: "Hours Recorded", value: `${(totalMinutes / 60).toFixed(1)}h`, icon: Clock, color: "text-purple-600 bg-purple-50 dark:bg-purple-900/20" },
            { label: "Plan", value: profile?.subscription?.plan === "monthly" ? "Pro" : "Trial", icon: Bot, color: "text-amber-600 bg-amber-50 dark:bg-amber-900/20" },
          ].map((stat) => (
            <div key={stat.label} className="rounded-xl border border-border/60 bg-card p-4">
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-3 ${stat.color}`}>
                <stat.icon className="w-4 h-4" />
              </div>
              <div className="font-display font-700 text-2xl">{stat.value}</div>
              <div className="text-xs text-muted-foreground mt-0.5">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Meeting list */}
      <div className="rounded-xl border border-border/60 bg-card overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-border/40">
          <h3 className="font-display font-600 text-sm">Meeting History</h3>
          <button
            onClick={() => refetch()}
            className="p-1.5 rounded-lg hover:bg-accent transition-colors text-muted-foreground hover:text-foreground"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-16">
            <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
          </div>
        ) : meetings?.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center px-4">
            <div className="w-14 h-14 rounded-2xl bg-muted flex items-center justify-center mb-4">
              <Bot className="w-7 h-7 text-muted-foreground" />
            </div>
            <h4 className="font-display font-600 text-base mb-2">No meetings yet</h4>
            <p className="text-sm text-muted-foreground mb-5 max-w-xs">
              Deploy your first AI clone to a meeting and your history will appear here.
            </p>
            <Button onClick={() => navigate("/meetings/new")}>
              <Plus className="w-4 h-4 mr-2" /> Deploy your first bot
            </Button>
          </div>
        ) : (
          <div className="divide-y divide-border/40">
            {meetings?.map((meeting) => {
              const statusCfg = STATUS_CONFIG[meeting.status] ?? STATUS_CONFIG.pending;
              const platform = PLATFORM_LABELS[meeting.platform] ?? "Meeting";
              const isLive = meeting.status === "recording" || meeting.status === "joining";
              return (
                <div
                  key={meeting.id}
                  className="flex items-center gap-4 px-5 py-4 hover:bg-muted/30 transition-colors cursor-pointer group"
                  onClick={() => navigate(`/meetings/${meeting.id}`)}
                >
                  {/* Status indicator */}
                  <div className="flex-shrink-0">
                    <div className={`w-2.5 h-2.5 rounded-full ${isLive ? "bg-red-500 animate-pulse" : meeting.status === "completed" ? "bg-emerald-500" : meeting.status === "failed" ? "bg-rose-400" : "bg-amber-400"}`} />
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="font-medium text-sm truncate">
                        {meeting.title ?? `${platform} Meeting`}
                      </span>
                      <Badge variant="secondary" className="text-[10px] px-1.5 py-0 flex-shrink-0">{platform}</Badge>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground">
                      <span>{formatDistanceToNow(new Date(meeting.createdAt), { addSuffix: true })}</span>
                      {meeting.durationFormatted && (
                        <>
                          <span>·</span>
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" /> {meeting.durationFormatted}
                          </span>
                        </>
                      )}
                      {meeting.participantCount && (
                        <>
                          <span>·</span>
                          <span className="flex items-center gap-1">
                            <Users className="w-3 h-3" /> {meeting.participantCount}
                          </span>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Status badge */}
                  <Badge className={`text-xs px-2.5 py-0.5 border-0 font-500 flex-shrink-0 ${statusCfg.className}`}>
                    {statusCfg.label}
                  </Badge>

                  {/* Arrow */}
                  {meeting.status === "completed" && (
                    <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-foreground transition-colors flex-shrink-0" />
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
