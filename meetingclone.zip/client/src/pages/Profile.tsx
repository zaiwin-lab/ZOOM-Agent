import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { useState, useRef } from "react";
import { Upload, Save, Loader2, User, Mail, Shield } from "lucide-react";

export default function Profile() {
  const { user } = useAuth();
  const { data: profile, refetch } = trpc.profile.get.useQuery();
  const [displayName, setDisplayName] = useState(profile?.user?.displayName ?? user?.name ?? "");
  const [avatarPreview, setAvatarPreview] = useState<string | null>(profile?.user?.avatarUrl ?? null);
  const [avatarBase64, setAvatarBase64] = useState<string | null>(null);
  const [avatarMime, setAvatarMime] = useState("image/jpeg");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const updateProfile = trpc.profile.update.useMutation({
    onSuccess: () => { toast.success("Profile updated!"); refetch(); },
    onError: (err) => toast.error("Update failed", { description: err.message }),
  });

  const uploadAvatar = trpc.profile.uploadAvatar.useMutation({
    onSuccess: (data) => {
      setAvatarPreview(data.avatarUrl);
      toast.success("Avatar updated!");
      refetch();
    },
    onError: (err) => toast.error("Upload failed", { description: err.message }),
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) { toast.error("Image too large (max 2MB)"); return; }
    const reader = new FileReader();
    reader.onload = (ev) => {
      const dataUrl = ev.target?.result as string;
      setAvatarPreview(dataUrl);
      setAvatarBase64(dataUrl.split(",")[1]);
      setAvatarMime(file.type);
    };
    reader.readAsDataURL(file);
  };

  const handleSave = async () => {
    if (avatarBase64) {
      await uploadAvatar.mutateAsync({ base64: avatarBase64, mimeType: avatarMime });
      setAvatarBase64(null);
    }
    await updateProfile.mutateAsync({ displayName: displayName.trim() || undefined });
  };

  const initials = (displayName || user?.name || "U").split(" ").map((n: string) => n[0]).join("").toUpperCase().slice(0, 2);
  const isSaving = updateProfile.isPending || uploadAvatar.isPending;

  return (
    <AppLayout title="Profile">
      <div className="max-w-lg mx-auto">
        <div className="mb-8">
          <h2 className="font-display text-2xl font-700 tracking-tight mb-1">Your Profile</h2>
          <p className="text-muted-foreground text-sm">Manage your account details and bot identity.</p>
        </div>

        {/* Avatar section */}
        <div className="rounded-xl border border-border/60 bg-card p-6 mb-4">
          <h3 className="font-display font-600 text-sm mb-4">Profile Photo</h3>
          <div className="flex items-center gap-5">
            <div className="relative">
              <Avatar className="w-20 h-20 border-2 border-border">
                <AvatarImage src={avatarPreview ?? undefined} />
                <AvatarFallback className="bg-primary/10 text-primary font-700 text-xl">{initials}</AvatarFallback>
              </Avatar>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-md hover:bg-primary/90 transition-colors"
              >
                <Upload className="w-3.5 h-3.5" />
              </button>
              <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
            </div>
            <div>
              <p className="text-sm font-medium mb-1">Upload a photo</p>
              <p className="text-xs text-muted-foreground mb-2">JPG, PNG or GIF. Max 2MB.</p>
              <Button variant="outline" size="sm" onClick={() => fileInputRef.current?.click()}>
                <Upload className="w-3.5 h-3.5 mr-1.5" /> Choose file
              </Button>
            </div>
          </div>
        </div>

        {/* Account info */}
        <div className="rounded-xl border border-border/60 bg-card p-6 mb-4">
          <h3 className="font-display font-600 text-sm mb-4">Account Details</h3>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="displayName" className="text-sm font-medium">Display Name</Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="displayName"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="Your display name"
                  className="pl-9 h-11"
                  maxLength={128}
                />
              </div>
              <p className="text-xs text-muted-foreground">This will be used as the default bot name in meetings.</p>
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm font-medium">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input value={user?.email ?? ""} disabled className="pl-9 h-11 bg-muted/30 text-muted-foreground" />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm font-medium">Role</Label>
              <div className="flex items-center gap-2 h-11 px-3 rounded-lg border border-border/60 bg-muted/30">
                <Shield className="w-4 h-4 text-muted-foreground" />
                <Badge variant="secondary" className="capitalize">{user?.role ?? "user"}</Badge>
              </div>
            </div>
          </div>
        </div>

        {/* Subscription info */}
        <div className="rounded-xl border border-border/60 bg-card p-6 mb-6">
          <h3 className="font-display font-600 text-sm mb-3">Subscription</h3>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium capitalize">
                {profile?.subscription?.plan === "monthly" ? "Pro Monthly" : profile?.subscription?.plan === "free_trial" ? "Free Trial" : "No Plan"}
              </p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Status: <span className={`font-medium ${profile?.subscription?.status === "active" ? "text-emerald-600" : "text-rose-600"}`}>
                  {profile?.subscription?.status ?? "—"}
                </span>
              </p>
            </div>
            <Button variant="outline" size="sm" onClick={() => window.location.href = "/subscription"}>
              Manage
            </Button>
          </div>
        </div>

        <Button className="w-full h-11 font-600" onClick={handleSave} disabled={isSaving}>
          {isSaving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
          Save changes
        </Button>
      </div>
    </AppLayout>
  );
}
