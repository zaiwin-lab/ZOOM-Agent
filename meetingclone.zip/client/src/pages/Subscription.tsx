import AppLayout from "@/components/AppLayout";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useState } from "react";
import { CheckCircle2, CreditCard, Loader2, AlertCircle, Zap, Calendar, X } from "lucide-react";
import { format } from "date-fns";

const PLAN_FEATURES = [
  "Unlimited meetings per month",
  "Real-time transcription with speaker ID",
  "AI summaries, highlights & action items",
  "Full transcript search",
  "PDF & text export",
  "Custom bot name & avatar",
  "Meeting history & analytics",
  "Priority support",
];

export default function Subscription() {
  const { data: sub, refetch } = trpc.subscription.get.useQuery();
  const [showConfirmCancel, setShowConfirmCancel] = useState(false);

  const upgrade = trpc.subscription.upgrade.useMutation({
    onSuccess: () => { toast.success("Upgraded to Pro Monthly!"); refetch(); },
    onError: (err) => toast.error("Upgrade failed", { description: err.message }),
  });

  const cancel = trpc.subscription.cancel.useMutation({
    onSuccess: () => { toast.success("Subscription cancelled."); setShowConfirmCancel(false); refetch(); },
    onError: (err) => toast.error("Cancellation failed", { description: err.message }),
  });

  const isPro = sub?.plan === "monthly" && sub?.status === "active";
  const isTrial = sub?.plan === "free_trial" && sub?.status === "active";
  const isCancelled = sub?.status === "cancelled" || sub?.plan === "cancelled";

  return (
    <AppLayout title="Subscription">
      <div className="max-w-lg mx-auto">
        <div className="mb-8">
          <h2 className="font-display text-2xl font-700 tracking-tight mb-1">Subscription</h2>
          <p className="text-muted-foreground text-sm">Manage your plan and billing.</p>
        </div>

        {/* Current plan card */}
        <div className="rounded-xl border border-border/60 bg-card p-6 mb-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display font-600 text-sm">Current Plan</h3>
            <Badge
              className={`text-xs px-2.5 py-0.5 border-0 font-500 ${
                isPro ? "status-completed" : isTrial ? "status-joining" : "status-failed"
              }`}
            >
              {isPro ? "Active" : isTrial ? "Trial" : "Cancelled"}
            </Badge>
          </div>

          <div className="flex items-baseline gap-2 mb-1">
            <span className="font-display text-3xl font-800">
              {isPro ? "$29" : isTrial ? "$0" : "—"}
            </span>
            {(isPro || isTrial) && <span className="text-muted-foreground text-sm">/month</span>}
          </div>
          <p className="text-sm font-medium mb-1">
            {isPro ? "Pro Monthly" : isTrial ? "Free Trial (First Month)" : "No Active Plan"}
          </p>

          {sub?.trialEndsAt && isTrial && (
            <div className="flex items-center gap-2 mt-3 text-xs text-amber-600 dark:text-amber-400">
              <Calendar className="w-3.5 h-3.5" />
              Trial ends {format(new Date(sub.trialEndsAt), "PPP")}
            </div>
          )}
          {sub?.currentPeriodEnd && isPro && (
            <div className="flex items-center gap-2 mt-3 text-xs text-muted-foreground">
              <Calendar className="w-3.5 h-3.5" />
              Next billing date: {format(new Date(sub.currentPeriodEnd), "PPP")}
            </div>
          )}
          {sub?.cancelledAt && isCancelled && (
            <div className="flex items-center gap-2 mt-3 text-xs text-rose-600">
              <AlertCircle className="w-3.5 h-3.5" />
              Cancelled on {format(new Date(sub.cancelledAt), "PPP")}
            </div>
          )}
        </div>

        {/* Upgrade card */}
        {!isPro && (
          <div className="rounded-xl border-2 border-primary bg-card p-6 mb-4 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full -translate-y-1/2 translate-x-1/2" />
            <div className="relative">
              <div className="flex items-center gap-2 mb-1">
                <Zap className="w-4 h-4 text-primary" />
                <h3 className="font-display font-600 text-sm">Upgrade to Pro</h3>
              </div>
              {isTrial && (
                <Badge variant="secondary" className="mb-3 bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 border-0 text-xs">
                  🎉 First month FREE — no charge today
                </Badge>
              )}
              <div className="flex items-baseline gap-1 mb-4">
                <span className="font-display text-2xl font-800">$29</span>
                <span className="text-muted-foreground text-sm">/month after trial</span>
              </div>

              <div className="space-y-2 mb-5">
                {PLAN_FEATURES.map((f) => (
                  <div key={f} className="flex items-center gap-2.5 text-sm">
                    <CheckCircle2 className="w-3.5 h-3.5 text-primary flex-shrink-0" />
                    {f}
                  </div>
                ))}
              </div>

              <Button
                className="w-full h-11 font-600 shadow-lg shadow-primary/20"
                onClick={() => upgrade.mutate()}
                disabled={upgrade.isPending}
              >
                {upgrade.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : (
                  <CreditCard className="w-4 h-4 mr-2" />
                )}
                {isTrial ? "Activate Pro (free for 30 days)" : "Upgrade to Pro"}
              </Button>
              <p className="text-center text-xs text-muted-foreground mt-2">Cancel anytime. No hidden fees.</p>
            </div>
          </div>
        )}

        {/* Cancel section */}
        {isPro && !showConfirmCancel && (
          <div className="rounded-xl border border-border/60 bg-card p-5">
            <h3 className="font-display font-600 text-sm mb-1">Cancel Subscription</h3>
            <p className="text-xs text-muted-foreground mb-3">
              You can cancel anytime. Your access continues until the end of the billing period.
            </p>
            <Button
              variant="outline"
              size="sm"
              className="text-destructive border-destructive/30 hover:bg-destructive/5"
              onClick={() => setShowConfirmCancel(true)}
            >
              <X className="w-3.5 h-3.5 mr-1.5" /> Cancel subscription
            </Button>
          </div>
        )}

        {showConfirmCancel && (
          <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-5 animate-fade-up">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <h3 className="font-display font-600 text-sm mb-1">Are you sure?</h3>
                <p className="text-xs text-muted-foreground mb-4">
                  Your subscription will be cancelled. You'll lose access to Pro features at the end of your billing period.
                </p>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => cancel.mutate()}
                    disabled={cancel.isPending}
                  >
                    {cancel.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin mr-1.5" /> : null}
                    Yes, cancel
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => setShowConfirmCancel(false)}>
                    Keep subscription
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
